#!/usr/bin/env perl

use strict;
use warnings;
use utf8;

use constant {
    RETURN_IF_FOUND => 1,
    MAX_TERM_WIDTH  => 65
};

use Data::Dumper;
use Encode qw( from_to );
use File::Basename qw( basename );
use File::Spec::Functions qw( :ALL );
use FileHandle;
use Getopt::Long;
use Perl6::Say;
use Pod::Usage;
use Win32::AutoGlob;
use Win32::Die;
use Win32::OLE;


# TODO:
#   プレイリスト名を表示してItemByNameでプレイリストを取得したあと
#       Visible(かreveal)にするかPlayFirstTrack()する
#   cmd_search()
#   Perlの-eオプションみたいなやつ
#   cmd_def()を複数行に対応

# FIXME:
#   echo, sayの正規表現を直す( "\" という引数も正常として認識されてしまう)
#   cmd_pager(), cmd_get_around_playlists()


our $debug         = 0;
our $VERSION       = 1.07;
our $force_execute = 0;
our $shell_mode    = 0;

our $itunes;    # COM object
our $ignored = '[ \t\n:;]';
our $trail  = qr/(?:\\|:|do)/;
our $end    = qr/end\s*(#.*)?/;

our $OPT;
$OPT->{PAGER} = 'less';
$OPT->{PIPED} = 0;

# init() will initialize this by requiring commands.pl
our %commands;



### FUNCTIONS ###

### debug - begin
### for debug print.
sub p {
    return unless $debug;
    my $str   = shift || '';
    my $fname = shift;
    my $msg   = encode(
        'sjis',
        "[debug]### $str ###\n"
    );

    if( defined $fname ) {
        my $FH = FileHandle->new( ">> $fname" );
        print $FH $msg;
        $FH->close;
    } else {
        warn $msg;
    }
}


sub warn_if_debug {
    my $msg = shift || die;
    warn $msg   if( $debug );
}


sub stop_if_debug() {
    if( $debug ) {
        print STDERR "Press enter....";
        STDERR->flush;
        <STDIN>;
    }
}
### debug - end


sub cmd_debug {
    my $what = shift || die;
    my @args = @_    or ();


    if( $what eq 'on' ) {
        $debug = 1;

    } elsif( $what eq 'off' ) {
        $debug = 0;

    } elsif( $what eq 'cmd' ) {
        for my $key ( sort keys %commands ) {
            my @cmds = split /\|/, ( split /\@/, $key )[0];
            say join ", ", @cmds;
        }

    } elsif( $what eq 'test' ) {
        if( -f 'test.it' ) {
            cmd_load( '"', 'test.it' );
        } else {
            warn_if_debug "warning: not found 'test.it'...\n";
        }

    } elsif( $what eq 'eval' ) {
        eval join ' ', @args;

    } elsif( $what eq 'dump' ) {
        local $Data::Dumper::Sortkeys = 1;
        local $Data::Dumper::Indent   = 1;
        local $Data::Dumper::Terse    = 1;
        p Dumper( $itunes ), 'dump.log';

    } elsif( $what eq 'reload' ) {
        # FIXME: requireは既にロードしたものは実行しない
        require 'commands.pl';

    } elsif( $what eq 'code' ) {
        # some test code here...
    }
}


sub cmd_help {
    my $what_help = shift;

    if( not defined $what_help ) {
        my $col       = 0;    # How many lines?
        my $cur       = '';
        my @outputs;

        # show all commands.
        for my $key ( sort keys %commands ) {
            my @cmds = split /\|/, ( split /\@/, $key )[0];
            my $cmd  = join ",", @cmds;

            $cur .= "    $cmd";
            if( length( $cur ) >= MAX_TERM_WIDTH ) {
                say $cur;
                $cur = '';
            }
        }

    } elsif( $what_help eq 'verbose' ) {
        pod2usage(
            -verbose => 2,
            -exitval => 'noexit'
        );
    }
}


sub cmd_version {
    say "itunes v", $itunes->version;
    say basename( $0 ) . " v$VERSION";
}


sub init() {

    # flush
    STDOUT->autoflush( 1 );
    STDERR->autoflush( 1 );


    # get a COM object.
    print "starting iTunes...";
    $itunes = Win32::OLE->new( 'iTunes.Application' )
        or die "Could not find iTunes COM object...\n";
    print "Done.\n\n";

    # define %commands, and subs associated with its $commands{name}->{subs}
    require 'commands.pl';

    # NOTE: used in cmd_pager().
    $OPT->{STDIN}  = \*STDIN;
    $OPT->{STDOUT} = \*STDOUT;
    $OPT->{STDERR} = \*STDERR;

    # return $stdin refference.
    if( @ARGV ) {
        my $file = shift @ARGV;
        die "Not found '$file'\n"   if( not -f $file );
        my $stdin = FileHandle->new( "< $file" );
        die $!      if( not defined $stdin );

        $OPT->{SHELL} = 'file';
        return $stdin;

    } else {
        $OPT->{SHELL} = 'interactive';
        return \*STDIN;
    }
}


# XXX
sub command_read($;$) {
    my $stdin  = shift || die;
    my $prompt = shift || '';
    my $lines = '';     # 入力した行($inputは１行バッファ)
    my $multiline = 0;


    while( 1 ) {
        my $input = <$stdin>;

        if( not defined $input ) {  # EOF
            if( $lines ) {
                return $lines;  # read a few lines yet.
            } else {
                return undef;   # No read lines. just undef.
            }
        }

        chomp( $input );

        # 末尾に$trailがあったら複数行モードに移行
        if( $input =~ s/$trail(?:\s*#.*)?$// ) {
            $multiline++;
        } elsif( $input =~ s/$end(?:\s*#.*)?$// ) {
            $multiline--;
        }

        # 結合
        if( $lines ) {
            $lines .= "\n";
        }
        $lines .= $input;


        if( $multiline == 0 ) {
            return $lines;

        } elsif( $multiline > 0 ) {     # for
            print $prompt x $multiline;
            next;

        } else {    # input begins with 'end'?
            $multiline = 0;
        }
    }
}


# Make regex by evaluating 'regex' key's value.
# And split name and info.
sub command_eval_regex($$) {
    my $regex    = shift || die;
    my $cmd_info = shift || die;
    my ( $cmd, $info ) = split /\@/, $cmd_info;
    my %struct;


    if( defined $info ) {
        my @infos = split //, $info;


        while( @infos ) {
            my $opt = shift @infos;

            if( $opt eq 'a' ) {
                my $arg_n = shift @infos;
                if( $arg_n !~ /^[\+\*\?\d]$/ ) {
                    warn_if_debug "warning: arg info is invalid.\n";
                    warn_if_debug "warning: Debug Trace: "
                        . "option is '$opt', invalid value is '$arg_n'.\n";
                    next;
                }
                $struct{args} = $arg_n;
            } elsif( $opt eq 'i' ) {
                $struct{interactive} = 1;
            }
        }
    }

    ( eval( $regex ), \%struct );
}


sub is_valid_args($@) {
    my ( $info, $cmd, @args ) = @_;

    if( exists $info->{args} && $info->{args} ) {
        my $err = '';
        if( $info->{args} eq '*' ) {
            unless( @args >= 0 ) {
                $err = $info->{args};
            }

        } elsif( $info->{args} eq '+' ) {
            unless( @args > 0 ) {
                $err = $info->{args};
            }

        } elsif( $info->{args} eq '?' ) {
            unless( @args == 0 || @args == 1 ) {
                $err = $info->{args};
            }

        } elsif( $info->{args} =~ /^\d+$/ ) {
            unless( @args == $info->{args} ) {
                $err = $info->{args};
            }
        }

        if( $err ) {
            warn_if_debug "warning: "
                . "$cmd has not matched arg type '$err'.\n";
#             return undef;
        }
    }

    1;
}

# 0      when parse end
# undef  when error
sub command_parse($;$) {
    my $cmd = shift || return 1;
    my $opt = shift || 0;


    ### debug - begin
    p "calling command_parse()...";
    ### debug - end


    # execute once per one loop
EXEC_ONCE:  while( $cmd ) {


        # spaces, and characters to be ignored.
        $cmd =~ s/^$ignored+//;
        return 1        if( $cmd =~ /^#/ );
        return 0        if( ! $cmd );

        # get N times to run command.
        my $times = 1;
        if( $cmd =~ s/^(\d+)// ) {
            if( $1 > 0 ) {
                $times = $1;
            } else {
                warn_if_debug "warning: invalid times '$1'.\n";
                return $force_execute;    # continue reading if $force_execute.
            }
        }


        # find applicable command
        foreach my $cmd_name ( keys %commands ) {
            my $regex  = $commands{$cmd_name}{regex};
            my $proc   = $commands{$cmd_name}{proc};
            my $info;

            # make regex from template.
            # TODO: make regex in init() !!
            #       and macro made by cmd_def(),
            #       will be evaluated just then.
            ( $regex, $info ) = command_eval_regex( $regex, $cmd_name );

            # spaces, and characters to be ignored.
            # NOTE: loop never ends if /^$ignored*/.
            next            if( $cmd =~ s/^$ignored+// );
            return 1        if( $cmd =~ /^#/ || !$cmd );


            # found !!
            if( $cmd =~ /$regex/ ) {

                # get matches wraped with paren.
                my @parens = get_matches();

                # if the command is not allowed to exec
                # in non-interactive mode.
                if( exists $info->{interactive}
                        && $OPT->{SHELL} ne 'interactive' )
                {
                    warn_if_debug "warning: '$parens[0]' is not allowed"
                            . "to exec in non-interactive mode.";
                    $cmd =~ s/$regex//;
                    $times = 0;
                    next;
                }

                # check args comparing $info
                if( ! is_valid_args( $info, @parens ) ) {
                    if( not $force_execute ) {
                        return undef;
                    }
                }

                # if requested to return result when found a command.
                if( $opt == RETURN_IF_FOUND ) {
                    return $times, $proc, @parens;
                }


                ### debug - begin
                p "command_parse(): return if $opt";
                p "matched regex '$regex' at '$&'.";
                p "excuting '$parens[0]'...";
                p sprintf '@parens:[%s]', join ", ", @parens;
                ### debug - end

                # execute N times.
                for ( 1..$times ) {
                    $proc->( @parens[1..$#parens] );
                }
                $cmd =~ s/$regex//;

                ### debug - begin
                p "excuted '$parens[0]'...";
                ### debug - end

                next EXEC_ONCE;
            }
        }

        
        warn_if_debug sprintf "warning: unknown command '%s'.\n",
                                substr( $cmd, 0, 1 );
        warn "Debug Trace:\n  [$cmd]";
        print "\n";

        $cmd = substr( $cmd, 1 );

        # return on parse error.
        if( not $force_execute ) {
            return undef;
        }
    }

    return 0;
}


# 現在の$1, $2を調べてマッチしたぶんを配列で返す
sub get_matches() {
    my @args;

    for( 1..10 ) {
        if( eval "defined \$$_" ) {
            push @args, eval "\$$_"
        } else {
            last;
        }
    }

    @args;
}


### FUNCTIONS ###

### MAIN ###

# arguments
my $needhelp;
GetOptions(
    debug => \$debug,
    force => \$force_execute,
    shell => \$shell_mode,
    help  => \$needhelp,
) or pod2usage( -verbose => 2 );
pod2usage( -verbose => 2 )      if( $needhelp );


# read from file or stdin?
my $stdin = init();

# Main loop
while( 1 ) {
    my $lines = '';

    if( $shell_mode ) {
        print '$ ';

        $lines = command_read( $stdin, '> ' );

        # EOF
        if( not defined $lines ) {
            exit;
        }

        my ( $times, $proc, @parens ) = command_parse( $lines, RETURN_IF_FOUND );

        if( defined $proc ) {

            ### debug - begin
            p "execute...";
            ### debug - end

            for ( 1..$times ) {
                $proc->( @parens[ 1..$#parens ] );
            }

            ### debug - begin
            p "executed...";
            ### debug - end
        }

    } elsif( $OPT->{SHELL} eq 'interactive' ) {
        # user input
        print 'autotunes> ';
        $lines = command_read( $stdin, '... ' );

        p "--- we will exec ---";
        p $lines;


        if( not defined $lines ) {
            # when EOF.
            exit;

        } elsif ( $lines ) {
            next if( $lines =~ /^\s*$/ );

            command_parse( $lines );
        }

    } elsif( $OPT->{SHELL} eq 'file' ) {
        # file input
        $lines = command_read( $stdin, '... ' );


        if( not defined $lines ) {
            # when EOF.
            exit;

        } elsif ( $lines ) {
            next if( $lines =~ /^\s*$/ );

            command_parse( $lines );
        }
    }
}

say "\nbye.";
### MAIN ###

__END__

=head1 NAME

autotunes.pl - Manipulating iTunes from CLI


=head1 SYNOPSIS

$ perl autotunes.pl [-h] [file]


=head1 OPTIONS

    h, help             This help text.
    f, force            force parsing when error occurs.
    s, shell            entering shell mode.(This turns by 'shell' command, too.)
  

=head1 COMMANDS

    I, Info             Show more verbose information.
    Q, shutdown         Quit iTunes and this program.
    b, back             Back track.
    c, change           Play or Stop music.
                 (same thing you press the center button on iTunes)
    echo                Echo message from batch file.
    f, forward          Forward track.
    i, info             Show information about the music playing now.
    max                 Maximize window.
    mini                Toggle mini player.
    mute                Mute.
    p, play             Play music.
    q                   Quit this program.
    s, stop, pause      Stop music.
    srch, search        Search tracks. (Not implemented yet)
    tray                let iTunes window go to tray.
    vol [num]           Volume Control.


=head1 EXAMPLE

    > sl120 p   # play music after 120 seconds
    > p sl5 Q   # stop music and quit program(without iTunes) after 300 seconds
    > p sl1 c sl1 c sl1 c   # play , stop , play, stop each 1 second
    > ff fr re  # fastforward until you type enter.


=head1 USABILITY

no use.

