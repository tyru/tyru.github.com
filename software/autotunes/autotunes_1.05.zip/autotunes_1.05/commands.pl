#!/usr/bin/env perl
use strict;
use warnings;
use utf8;

use Win32::AutoGlob;
use Win32::Die;

use Encode;
use FileHandle;
use Getopt::Long;
use Perl6::Say;
use Pod::Usage;


our ( $debug, $itunes, $shell_mode, $force_execute );


# NOTE: �Œ���̂ЂȌ^ => qr/ ^ (�R�}���h) /mx
our %commands = (
    'debug'         => { 'regex' => 'qr/ ^ ($_) (?:\s*(on|off|cmd|test))? \b /mx',
                         'sub'   =>  \&cmd_debug },
    'h|help'        => { 'regex' => 'qr/ ^ ($_) \b /mx',
                         'sub'   => \&cmd_help, },
    'v|ver|version' => { 'regex' => 'qr/ ^ ($_) \b /mx',
                         'sub'   => \&cmd_version, },
    'q|quit|bye'    => { 'regex' => 'qr/ ^ ($_) \b /mx',
                         'sub'   => sub { exit } },
    'Q|Quit'        => { 'regex' => 'qr/ ^ ($_) \b /mx',
                         'sub'   => sub { $itunes->Quit(); exit } },
    'vol|volume'    => { 'regex' => 'qr/ ^ ($_) (?: \s* ([+-]? \d+)? ) \b /mx',
                         'sub'   => \&cmd_volume },

    'echo'      => { 'regex' => 'qr/ ^ ($_) (?: \s* (["\']) (.*?) \2 )/mx',
                     'sub'   => \&cmd_echo },
    'say'       => { 'regex' => 'qr/ ^ ($_) (?: \s* (["\']) (.*?) \2 )/mx',
                     'sub'   =>  sub { cmd_echo( $_[0], $_[1] . "\n" ) } },
    'sl|sleep'  => { 'regex' => 'qr/ ^ ($_) (?: \s* (\d+) ) \b /mx',
                     'sub'   => sub { sleep shift } },
    'p|play'    => { 'regex' => 'qr/ ^ ($_) \b /mx',
                     'sub'   => sub { $itunes->Play() } },
    's|stop'    => { 'regex' => 'qr/ ^ ($_) \b /mx',
                     'sub'   => sub { $itunes->Pause() } },
    'c|change'  => { 'regex' => 'qr/ ^ ($_) \b /mx',
                     'sub'   => sub { $itunes->PlayPause() } },
    'f|forward' => { 'regex' => 'qr/ ^ ($_) \b /mx',
                     'sub'   => sub { $itunes->NextTrack() } },
    'b|back'    => { 'regex' => 'qr/ ^ ($_) \b /mx',
                     'sub'   => sub { $itunes->BackTrack() } },

    'i|info' => { 'regex' => 'qr/ ^ ($_) (?: \s* (verbose) )? \b /mx',
                  'sub'   => \&cmd_show_info },
    'I|Info' => { 'regex' => 'qr/ ^ ($_) \b /mx',
                  'sub'   => sub { cmd_show_info( 'verbose' ) } },
    'rate'   => { 'regex' => 'qr/ ^ ($_) (?: \s* ([0-5]+) ) \b /mx',
                  'sub'   => sub { $itunes->CurrentTrack->{Rating} = shift() * 20 } },
    'l|list' => { 'regex' => 'qr/ ^ ($_) (?: \s* (all) )? \b /mx',
                  'sub'   => \&cmd_list },
    'L|List' => { 'regex' => 'qr/ ^ ($_) \b /mx',
                  'sub'   => sub { cmd_list( 'all' ) } },

    'srch|search' => { 'regex' => 'qr/ ^ ($_) (?: \s* \( (.*?) \) ) /mx',
                       'sub'   => \&cmd_search },

    'mute' => { 'regex' => 'qr/ ^ ($_) ( [\\?!] )? /mx',
                'sub'   => sub { cmd_with_toggle(
                                    shift,
                                    \$itunes->{Mute} ) } },
    'max'  => { 'regex' => 'qr/ ^ ($_) ( [\\?!] )? /mx',
                'sub'   => sub { cmd_with_toggle(
                                    shift,
                                    \$itunes->BrowserWindow->{Maximized} ) } },
    'mini' => { 'regex' => 'qr/ ^ ($_) ( [\\?!] )? /mx',
                'sub'   => sub { cmd_with_toggle(
                                    shift,
                                    \$itunes->BrowserWindow->{MiniPlayer} ) } },

    'tray' => { 'regex' => 'qr/ ^ ($_) ( [\\?!] )? /mx',
                'sub'   => sub { cmd_with_toggle(
                                    shift,
                                    \$itunes->BrowserWindow->{Minimized} ) } },

    # shell, load, for, etc...
    'shell' => { 'regex' => 'qr/ ^ ($_) ( [\\?!] )? /mx',
                 'sub'   => sub { cmd_with_toggle( shift, \$shell_mode ) } },
    'force' => { 'regex' => 'qr/ ^ ($_) ( [\\?!] )? /mx',
                 'sub'   => sub { cmd_with_toggle( shift, \$force_execute ) } },
    'load'  => { 'regex' => 'qr/ ^ ($_) (?: \s* (\S+) ) \b /mx',
                 'sub'   => \&cmd_load },
    'for'   => { 'regex' => 'qr/ ^ ($_) \s* ([1-9][0-9]*) (?:\s* times)?
                                $ignore_char* do
                                    \s* ([\w\W]*?)
                                $ignore_char* done /xm',
                 'sub'   => \&cmd_for },

#     qr/^while\s*\((.*?)\)/ => \&cmd_while,
#     qr/^if\s*\((.*?)\)\s*{(.*?)}/m => \&cmd_if,
);


### FUNCTIONS ###

sub cmd_volume {
    my $vol = shift;

    if( not defined $vol ) {
        # mute
        toggle( \$itunes->{mute} );
        return;
    }

    if( $vol =~ /^([+-])(\d+)/ ) {
        $vol = eval $itunes->{soundvolume} . " $1 $2";
    }

    # round to 0..100
    if( $vol >= 100 ) {
        $vol = 100;
    } elsif ( $vol < 0 ) {
        $vol = 0;
    }
    $itunes->{SoundVolume} = floor $vol;
}


sub convert_esc($$) {
    my $ch  = shift || die;
    my $msg = shift;


    if( $ch eq '\\' ) {
        "\\"
    } elsif( $ch eq 'a' ) {
        "\a"
    } elsif( $ch eq 'b' ) {
        "\b"
    } elsif( $ch eq 'cC' ) {
        "\cC"
    } elsif( $ch eq 'f' ) {
        "\f"
    } elsif( $ch eq 'n' ) {
        "\n"
    } elsif( $ch eq 'r' ) {
        "\r"
    } elsif( $ch eq 't' ) {
        "\t"
    } elsif( substr( $ch, 0, 1 ) eq 'l' ) {
        lc( $ch )
    } elsif( substr( $ch, 0, 1 ) eq 'u' ) {
        uc( $ch )
    } elsif( $ch eq 'L' && defined $msg ) {
        "\L$msg\E"
    } elsif( $ch eq 'Q' && defined $msg ) {
        "\Q$msg\E"
    } elsif( $ch eq 'U' && defined $msg ) {
        "\U$msg\E"
    } else {
        warn "warning: unexpected sequence.\n"   if( $debug );
        $ch;
    }
}


sub cmd_echo {
    my $quote = shift || die;
    my $msg   = shift || '';

    # convert
    if( $quote eq '"' ) {
        $msg =~ s/(?:\\(.|cC|l.|u.|L|Q|U)(?:(.*?)\\E)?)/ convert_esc( $1, $2 ) /eg;
    }

    print $msg;
}


sub cmd_show_info {
    my $opt = shift || '';


    my $track = $itunes->CurrentTrack;
    if( not $track ) {
        warn "not playing.\n";
        return;
    }

    # show basic information
    show_item_info(
        $track,
        qw( Name Artist Album )
    );
    say "Rate: " . "% " x ( $track->{Rating} / 20 );


    # verbose information
    if( $opt eq 'verbose' ) {
        show_item_info(
            $track,
            qw( Time SkippedCount Comment )
        );
        say sprintf "Size: %g MByte", $track->Size / 1048576;
        say sprintf "Playlist: %s [%d/%d]",
                $itunes->CurrentPlaylist->Name,
                $itunes->CurrentPlaylist->Tracks->Count,
                $itunes->LibraryPlaylist->Tracks->Count;
    }
}


sub cmd_list {
    my $all = shift eq 'all';
    my $tracks;

    if( $all ) {
        $tracks = $itunes->LibraryPlaylist->Tracks;
    } else {
        $tracks = $itunes->CurrentPlaylist->Tracks;
    }

    for ( 1..$tracks->Count ) {
        print "------------------------------------------\n";
        show_item_info(
            $tracks->Item( $_ ),
            qw( Name Artist )
        );
    }
}


sub cmd_search {
    my $opt = shift;

    if( not defined $opt ) {
        warn "No options.";
        return;
    }

    warn "not implemented yet.\n";

    #     eval "use Inline MzScheme => $opt";
}


sub cmd_load {
    my $fname = shift || die;
    my $FH = FileHandle->new( "< $fname" );
    if( not defined $FH ) {
        warn "error: Can't open $fname...\n";
        return;
    }

    while( 1 ) {
        my $input = command_read( $FH );

        if( not defined $input ) {  # EOF
            return;

        } elsif( $input ) {
            chomp( $input );
            next if( $input =~ /^\s*$/ );

            command_parse( $input );
        }
    }
}


sub cmd_with_toggle {
    my $toggle = shift || '';
    my $ref    = shift || die;

    if( $toggle eq '?' ) {
        toggle( $ref );
    } elsif( $toggle eq '!' ) {
        $$ref = 0;
    } else {
        $$ref = 1;
    }
}


sub toggle {
    my $val = shift || die;
    $$val = !$$val;
}


sub show_item_info {
    my $item = shift || die;
    my @lis  = @_    or die;

    ### debug - begin
    p sprintf '@lis:[%s]', join ", ", @lis;
    ### debug - end


#     if( not defined $PIPE ) {
#         $PIPE = IO::Pipe->new();
#         $PIPE->writer( $pager );
#     }

    for ( @lis ) {
        if( $item->{$_} ) {
            print sprintf "$_: %s\n", $item->{$_};
        }
    }
#         eval "\$item->{\$_} && say $PIPE "$_: " . \$item->{\$_}";
#         warn "eval error:\n$@\n"     if( $@ );
}


sub cmd_for {
    my ( $times, $group ) = @_ or die;
    
    ### debug - begin
    p "\$times:[$times]";
    p "\$group:[$group]";
    ### debug - end

    for ( 1..$times ) {
        command_parse( $group );
    }
}


# sleep but wake up and ask you when typed 'q' key.
sub sleep {
    my $sec  = shift;
    my $prev = time;

    while( time() - $prev < $sec ) {
        my $c = getch();

        if( $c && $c =~ /^q/ ) {
            print "Do you really want to quit?[y/n]: ";
            exit if( <STDIN> =~ /^[yY]/ );
        }
    }
}


1;
