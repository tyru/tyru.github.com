#!/usr/bin/env perl
use strict;
use warnings;
use utf8;

use constant {
    EXPECT_CODE     => 2,
    RETURN_IF_FOUND => 1
};

use Win32::AutoGlob;
use Win32::Die;

use Encode;
use FileHandle;
use Getopt::Long;
use Perl6::Say;
use Pod::Usage;


our $debug;
our $itunes;
our $shell_mode;
our $force_execute;
our %pagers;
our $pager;
our $piped;
our %IO;


# NOTE: �Œ���̂ЂȌ^ => qr/ ^ (�R�}���h) /mx
our %commands = (
    'debug'         => { 'regex' => 'qr/ ^ ($cmd) (?: \s* (on|off|cmd|test|dump|code|eval) )
                                                (?: $ignore_char* do
                                                        \s* ([\w\W]*?)
                                                    $ignore_char* done ) ?
                                                /mx',
                         'sub'   =>  \&cmd_debug },
    'h|help'        => { 'regex' => 'qr/ ^ ($cmd) \b /mx',
                         'sub'   => \&cmd_help },
    'v|ver|version' => { 'regex' => 'qr/ ^ ($cmd) \b /mx',
                         'sub'   => \&cmd_version },
    'q|quit|bye'    => { 'regex' => 'qr/ ^ ($cmd) \b /mx',
                         'sub'   => sub { exit } },
    'Q|Quit'        => { 'regex' => 'qr/ ^ ($cmd) \b /mx',
                         'sub'   => sub { $itunes->Quit(); exit } },
    'vol|volume'    => { 'regex' => 'qr/ ^ ($cmd) (?: \s* ([+-]? \d+)? ) \b /mx',
                         'sub'   => \&cmd_volume },

    'echo'      => { 'regex' => 'qr/ ^ ($cmd) (?: \s* (["\']) (.*?) \2 )/mx',
                     'sub'   => \&cmd_echo },
    'say'       => { 'regex' => 'qr/ ^ ($cmd) (?: \s* (["\']) (.*?) \2 )/mx',
                     'sub'   =>  sub { cmd_echo( shift, shift() . "\n" ) } },
    'sl|sleep'  => { 'regex' => 'qr/ ^ ($cmd) (?: \s* (\d+) ) \b /mx',
                     'sub'   => sub { sleep shift } },
    'p|play'    => { 'regex' => 'qr/ ^ ($cmd) \b /mx',
                     'sub'   => sub { $itunes->Play() } },
    's|stop'    => { 'regex' => 'qr/ ^ ($cmd) \b /mx',
                     'sub'   => sub { $itunes->Pause() } },
    'c|change'  => { 'regex' => 'qr/ ^ ($cmd) \b /mx',
                     'sub'   => sub { $itunes->PlayPause() } },
    'f|forward' => { 'regex' => 'qr/ ^ ($cmd) \b /mx',
                     'sub'   => sub { $itunes->NextTrack() } },
    'b|back'    => { 'regex' => 'qr/ ^ ($cmd) \b /mx',
                     'sub'   => sub { $itunes->BackTrack() } },
    'ff|fastforward' => { 'regex' => 'qr/ ^ ($cmd) (?: \s* (\d+) )? \b /mx',
                          'sub'   => sub { $itunes->FastForward(); $_[0] && sleep shift;
                                           $itunes->Resume() } },
    'bb|fastback'    => { 'regex' => 'qr/ ^ ($cmd) (?: \s* (\d+) )? \b /mx',
                          'sub'   => sub { $itunes->ReWind(); $_[0] && sleep shift;
                                           $itunes->Resume() } },
    'ss|resume'      => { 'regex' => 'qr/ ^ ($cmd) \b /mx',
                          'sub'   => sub { $itunes->Resume() } },
    'pl'             => { 'regex' => 'qr/ ^ ($cmd) (?: \s* ([+-]? \d+) ) \b /mx',
                          'sub'   => sub { cmd_get_around_playlists( 'pl', @_ ) } },
    'fp'             => { 'regex' => 'qr/ ^ ($cmd) (?: \s* ([+-]? \d+) )? \b /mx',
                          'sub'   => sub { cmd_get_around_playlists( 'fp', @_ ) } },
    'bp'             => { 'regex' => 'qr/ ^ ($cmd) (?: \s* ([+-]? \d+) )? \b /mx',
                          'sub'   => sub { cmd_get_around_playlists( 'bp', @_ ) } },
    'store'          => { 'regex' => 'qr/ ^ ($cmd) \b /mx',
                          'sub'   => sub { $itunes->GotoMusicStoreHomePage() } },

    'reveal'         => { 'regex' => 'qr/ ^ ($cmd) \b /mx',
                          'sub'   => sub { $itunes->CurrentTrack->Reveal() } },
    'i|info' => { 'regex' => 'qr/ ^ ($cmd) (?: \s* (verbose) )? \b /mx',
                  'sub'   => \&cmd_show_info },
    'I|Info' => { 'regex' => 'qr/ ^ ($cmd) \b /mx',
                  'sub'   => sub { cmd_show_info( 'verbose' ) } },
    'rate'   => { 'regex' => 'qr/ ^ ($cmd) (?: \s* ([0-5]+) ) \b /mx',
                  'sub'   => sub { $itunes->CurrentTrack->{Rating} = shift() * 20 } },
    'l|list' => { 'regex' => 'qr/ ^ ($cmd) (?: \s* (all|playlist) )? \b /mx',
                  'sub'   => \&cmd_list },
    'L|List' => { 'regex' => 'qr/ ^ ($cmd) \b /mx',
                  'sub'   => sub { cmd_list( 'playlist' ) } },

    'srch|search' => { 'regex' => 'qr/ ^ ($cmd) (?: \s* \( (.*?) \) ) /mx',
                       'sub'   => \&cmd_search },

    'mute' => { 'regex' => 'qr/ ^ ($cmd) ( [\\?!] )? /mx',
                'sub'   => sub { cmd_with_toggle(
                                    shift,
                                    \$itunes->{Mute} ) } },
    'max'  => { 'regex' => 'qr/ ^ ($cmd) ( [\\?!] )? /mx',
                'sub'   => sub { cmd_with_toggle(
                                    shift,
                                    \$itunes->BrowserWindow->{Maximized} ) } },
    'mini' => { 'regex' => 'qr/ ^ ($cmd) ( [\\?!] )? /mx',
                'sub'   => sub { cmd_with_toggle(
                                    shift,
                                    \$itunes->BrowserWindow->{MiniPlayer} ) } },

    'tray' => { 'regex' => 'qr/ ^ ($cmd) ( [\\?!] )? /mx',
                'sub'   => sub { cmd_with_toggle(
                                    shift,
                                    \$itunes->BrowserWindow->{Minimized} ) } },

    # shell, load, for, etc...
    'shell' => { 'regex' => 'qr/ ^ ($cmd) ( [\\?!] )? /mx',
                 'sub'   => sub { cmd_with_toggle( shift, \$shell_mode ) } },
    'force' => { 'regex' => 'qr/ ^ ($cmd) ( [\\?!] )? /mx',
                 'sub'   => sub { cmd_with_toggle( shift, \$force_execute ) } },
    'pager' => { 'regex' => 'qr/ ^ ($cmd) \s* (?: (more|less|on|off)
                                              | (eval) $ignore_char* do
                                                    \s* ([\w\W]*?)      # TODO: begin with not eval.
                                                $ignore_char* done ) ) \b /mx',
                 'sub'   => \&cmd_pager },
    'load'  => { 'regex' => 'qr/ ^ ($cmd) (?: \s* (["\']) (.*?) \2 ) /mx',
                 'sub'   => \&cmd_load },
    'for'   => { 'regex' => 'qr/ ^ ($cmd) \s* ([1-9][0-9]*) (?:\s* times)?
                                $ignore_char* do
                                    \s* ([\w\W]*?)
                                $ignore_char* done /xm',
                 'sub'   => \&cmd_for },

#     qr/^while\s*\((.*?)\)/ => \&cmd_while,
#     qr/^if\s*\((.*?)\)\s*{(.*?)}/m => \&cmd_if,
);


### FUNCTIONS ###

sub cmd_volume {
    my $vol = shift;

    if( not defined $vol ) {
        # mute
        toggle( \$itunes->{mute} );
        return;
    }

    if( $vol =~ /^([+-])(\d+)/ ) {
        $vol = eval $itunes->{soundvolume} . " $1 $2";
    }

    # round to 0..100
    if( $vol >= 100 ) {
        $vol = 100;
    } elsif ( $vol < 0 ) {
        $vol = 0;
    }
    $itunes->{SoundVolume} = floor $vol;
}


sub convert_esc($$) {
    my $ch  = shift || die;
    my $msg = shift;


    if( $ch eq '\\' ) {
        "\\"
    } elsif( $ch eq 'a' ) {
        "\a"
    } elsif( $ch eq 'b' ) {
        "\b"
    } elsif( $ch eq 'cC' ) {
        "\cC"
    } elsif( $ch eq 'f' ) {
        "\f"
    } elsif( $ch eq 'n' ) {
        "\n"
    } elsif( $ch eq 'r' ) {
        "\r"
    } elsif( $ch eq 't' ) {
        "\t"
    } elsif( substr( $ch, 0, 1 ) eq 'l' ) {
        lc( $ch )
    } elsif( substr( $ch, 0, 1 ) eq 'u' ) {
        uc( $ch )
    } elsif( $ch eq 'L' && defined $msg ) {
        "\L$msg\E"
    } elsif( $ch eq 'Q' && defined $msg ) {
        "\Q$msg\E"
    } elsif( $ch eq 'U' && defined $msg ) {
        "\U$msg\E"
    } else {
        warn "warning: unexpected sequence.\n"   if( $debug );
        $ch;
    }
}


sub cmd_echo {
    my $quote = shift || die;
    my $msg   = shift || '';

    # convert
    if( $quote eq '"' ) {
        $msg =~ s/(?:\\(.|cC|l.|u.|L|Q|U)(?:(.*?)\\E)?)/ convert_esc( $1, $2 ) /eg;
    }

    print $msg;
}


sub is_playing() {
    return defined $itunes->CurrentPlaylist;
}


# XXX
sub cmd_get_around_playlists {
    my $cmd = shift || die;
    my $n   = shift || 1;

    return      if( not is_playing );

    my $lib_lst = $itunes->LibraryPlaylist->Source->Playlists;
    my $max_id  = $lib_lst->Count;
    my $cur_id  = $itunes->CurrentPlaylist->Index - 5;



    p "current is [$cur_id/$max_id]";


    if( $cmd eq 'pl' ) {
        my $item = $lib_lst->Item( $n );
        $item->PlayFirstTrack();

    } elsif( $cmd eq 'fp' ) {
        my $id = $cur_id + $n;

        if( $id <= 0 ) {
            $id = 1;
        } elsif( $id >= $max_id ) {
            $id = $max_id;
        }
        my $item    = $lib_lst->Item( $id );
        $item->{Visible} = 1;

    } elsif( $cmd eq 'bp' ) {
        my $id = $cur_id - $n;

        p "\$id:[$id]";

        if( $id <= 0 ) {
            $id = 1;
        } elsif( $id >= $max_id ) {
            $id = $max_id;
        }
        my $item    = $lib_lst->Item( $id );
        $item->{Visible} = 1;
#         $lib_lst->Item( $id )->PlayFirstTrack();
    }
}


sub cmd_show_info {
    my $opt = shift || '';


    my $track = $itunes->CurrentTrack;
    if( not $track ) {
        warn "not playing.\n";
        return;
    }

    # show basic information
    show_item_info(
        $track,
        qw( Name Artist Album )
    );
    say "Rate: " . "% " x ( $track->{Rating} / 20 );


    # verbose information
    if( $opt eq 'verbose' ) {
        show_item_info(
            $track,
            qw( Time SkippedCount Comment )
        );
        say sprintf "Size: %g MByte", $track->Size / 1048576;
        say sprintf "Playlist: %s [%d/%d]",
                $itunes->CurrentPlaylist->Name,
                $itunes->CurrentPlaylist->Tracks->Count,
                $itunes->LibraryPlaylist->Tracks->Count;
    }
}


sub cmd_list {
    my $opt = shift;
    my $tracks;

    if( $opt eq 'all' ) {
        $tracks = $itunes->LibraryPlaylist->Tracks;
    } elsif( $opt eq 'playlist' ) {
        $tracks = $itunes->LibraryPlaylist->Source->Playlists;
    } else {
        $tracks = $itunes->CurrentPlaylist->Tracks;
    }

    for ( 1..$tracks->Count ) {
        print "----- Item $_ -----\n";
        show_item_info(
            $tracks->Item( $_ ),
            qw( Name Artist playlistID )
        );
    }
}


sub cmd_search {
    my $opt = shift;

    if( not defined $opt ) {
        warn "No options.";
        return;
    }

    warn "not implemented yet.\n";

    #     eval "use Inline MzScheme => $opt";
}


# XXX
sub cmd_pager {
    my @opts  = @_;
    my $state = 0;

    p "calling cmd_pager()...";
    p sprintf '@opts:[%s]', join ", ", @opts;


    foreach my $opt ( @opts ) {

        if( $opt eq 'on' ) {
            if( not $piped ) {
                my $FH  = IO::Pipe->new;
                $FH->writer( $pager );
                die $!    if( not defined $FH );

                system( 'cls' );
                $IO{STDOUT} = $FH;
                $piped  = 1;
            }

        } elsif( $opt eq 'off' ) {
            if( $piped ) {
                $IO{STDOUT} = \*STDOUT;
                $piped = 0;
            }

        } elsif( $opt eq 'more' ) {
            $pager = $pagers{more};

        } elsif( $opt eq 'less' ) {
            $pager = $pagers{less};

        } elsif( $opt eq 'eval' ) {
            $state = EXPECT_CODE;     # code after this

        } elsif( $state == EXPECT_CODE ) {
#             command_parse( $opt );

            p "\$opt:[$opt]";
            <STDIN>;

            my ( $sub, @args ) = command_parse( $opt, RETURN_IF_FOUND );

            if( defined $sub ) {
                # exec.
                $sub->( @args );
            }

            $state = 0;  # reset
        }
    }
}


sub cmd_load {
    my $fname = $_[1] || die;
    my $FH = FileHandle->new( "< $fname" );
    if( not defined $FH ) {
        warn "error: Can't open $fname...\n";
        return;
    }

    while( 1 ) {
        my $input = command_read( $FH );

        if( not defined $input ) {  # EOF
            return;

        } elsif( $input ) {
            chomp( $input );
            next if( $input =~ /^\s*$/ );

            command_parse( $input );
        }
    }
}


sub cmd_with_toggle {
    my $toggle = shift || '';
    my $ref    = shift || die;

    if( $toggle eq '?' ) {
        toggle( $ref );
    } elsif( $toggle eq '!' ) {
        $$ref = 0;
    } else {
        $$ref = 1;
    }
}


sub toggle {
    my $val = shift || die;
    $$val = !$$val;
}


sub show_item_info {
    my $item = shift || die;
    my @lis  = @_    or die;

    ### debug - begin
    p sprintf '@lis:[%s]', join ", ", @lis;
    ### debug - end


    for ( @lis ) {
        if( $item->{$_} ) {
            print sprintf "%s: %s\n", $_, $item->{$_};
        }
    }
#         eval "\$item->{\$_} && say $PIPE "$_: " . \$item->{\$_}";
#         warn "eval error:\n$@\n"     if( $@ );
}


sub cmd_for {
    my ( $times, $group ) = @_ or die;
    
    ### debug - begin
    p "\$times:[$times]";
    p "\$group:[$group]";
    ### debug - end

    for ( 1..$times ) {
        command_parse( $group );
    }
}


# sleep but wake up and ask you when typed 'q' key.
sub sleep {
    my $sec  = shift;
    my $prev = time;

    while( time() - $prev < $sec ) {
        my $c = getch();

        if( $c && $c =~ /^q/ ) {
            print "Do you really want to quit?[y/n]: ";
            exit if( <STDIN> =~ /^[yY]/ );
        }
    }
}


1;
