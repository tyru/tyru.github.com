#!/usr/bin/env perl

use strict;
use warnings;
use subs 'sleep';

use constant {
    TRUE         => 1,
    FALSE        => 0,
    RETURN_EVENT => -1
};

use Encode;
use File::Basename qw( basename );
use File::Spec::Functions qw( :ALL );
use FileHandle;
use Getopt::Long;
use IO::Pipe;
use POSIX qw( floor );
use Perl6::Say;
use Pod::Usage;
use Term::Getch;
use Win32::OLE;
use Win32;    # for Sleep


# TODO:
#   command_parse関数がコマンドを見つけたらそれを返す(あれば引数つき)
#   command_parse関数はcommand_execに渡すとき先頭の引数は渡さない

our $debug         = 0;
our $VERSION       = 1.01;

our $force_execute = 0;
our $shell_mode    = 0;
our $pager         = 'less';
our $PIPE;

our $itunes;    # COM object
our $ignore_char = '[\s\n:;]';


# NOTE: 引数が必要な時は '?' を付ける
#       最低限のひな型 => qr/ ^ (コマンド) /mx
our %commands = (
    qr/ ^ (debug) (?:\s*(cmds))? \b /mx
        => \&cmd_debug,
    qr/ ^ (h|help) \b /mx
        => \&cmd_help,
    qr/ ^ (v|ver|version) \b /mx
        => \&cmd_version,
    qr/ ^ (q|quit|bye) \b /mx
        => sub { exit },
    qr/ ^ (Q|Quit) \b /mx
        => sub { $itunes->Quit(); exit },

    qr/ ^ (vol) (?:\s*([+-]?\d+)?)? \b /mx
        => \&cmd_volume,
    qr/ ^ (echo) (?:\s*(["'])(.*?)\1)? /mx
        => \&cmd_echo,
    qr/ ^ (say) (?:\s*(["'])(.*?)\2)? /mx
        => sub { cmd_echo( $_[1], $_[2] . "\n" ) },
    qr/ ^ (sl(?:eep)) (?:\s*(\d+))? \b /mx
        => sub { sleep $_[0] },
    qr/ ^ (p|play) \b /mx
        => sub { $itunes->Play() },
    qr/ ^ (s|stop|pause) \b /mx
        => sub { $itunes->Pause() },
    qr/ ^ (c|change) \b /mx
        => sub { $itunes->PlayPause() },
    qr/ ^ (f|forward) \b /mx
        => sub { $itunes->NextTrack() },
    qr/ ^ (b|back) \b /mx
        => sub { $itunes->BackTrack() },
    qr/ ^ (i|info) (?:\s*(verbose))? \b /mx
        => \&cmd_show_info,
    qr/ ^ (I|Info) \b /mx
        => sub { cmd_show_info( 'verbose' ) },
    qr/ ^ (rate) \s* ([-2-5]+) \b /mx
        => sub { $itunes->CurrentTrack->{Rating} = shift() * 20 },
    qr/ ^ (l|list) \s* (all)? \b /mx
        => \&cmd_list,
    qr/ ^ (L|List) \b /mx
        => sub { cmd_list( 'all' ) },
    qr/ ^ (srch|search) \s* \( (.*?) \) /mx
        => \&cmd_search,

    # toggle
    qr/ ^ (mute) ([\?!])? /mx
        => sub { cmd_with_toggle(
                        shift,
                        \$itunes->{Mute} ) },
    qr/ ^ (max) ([\?!])? /mx
        => sub { cmd_with_toggle(
                        shift,
                        \$itunes->BrowserWindow->{Maximized} ) },
    qr/ ^ (mini) ([\?!])? /mx
        => sub { cmd_with_toggle(
                        shift,
                        \$itunes->BrowserWindow->{MiniPlayer} ) },
    qr/ ^ (tray) ([\?!])? /mx
        => sub { cmd_with_toggle(
                        shift,
                        \$itunes->BrowserWindow->{Minimized} ) },

    # shell, for, etc...
    qr/ ^ (shell) \b /mx
        => sub { $shell_mode = 1 },


#     qr/^while\s*\((.*?)\)/ => \&cmd_while,
#     qr/^if\s*\((.*?)\)\s*{(.*?)}/m => \&cmd_if,

    qr/ ^ (for) \s* ([1-9][0-9]*) (?:\s* times)?
        $ignore_char* do
            \s* ([\w\W]*?)
        $ignore_char* done /xm              => \&cmd_for,
);

### FUNCTIONS ###

### for debug print.
sub p {
    return unless $debug;
    my $str   = shift || '';
    my $fname = shift;
    my $msg   = encode(
        'sjis',
        "[debug]### $str ###\n"
    );

    if( defined $fname ) {
        my $FH = FileHandle->new( ">> $fname" );
        print $FH $msg;
        $FH->close;
    } else {
        warn $msg;
    }
}


sub cmd_debug {
    my $what = shift || die;

    if( $what eq 'cmds' ) {
        for ( keys %commands ) {
            warn "$_ : $commands{$_}\n";
        }
#     } elsif( $what eq 'test' ) {
    } else {
        warn "No debug command '$what'.\n";
    }
}


sub cmd_help {
    pod2usage(
        -verbose => 2,
        -exitval => 'NOEXIT'
    );
}


sub cmd_version {
    say "iTunes v", $itunes->Version;
    say basename( $0 ) . " v$VERSION";
}


sub cmd_volume {
    my $vol = shift;

    if( not defined $vol ) {
        # mute
        toggle( \$itunes->{Mute} );
        return;
    }

    if( $vol =~ /^([+-])(\d+)/ ) {
        $vol = eval $itunes->{SoundVolume} . " $1 $2";
    }

    # round to 0..100
    if( $vol >= 100 ) {
        $vol = 100;
    } elsif ( $vol < 0 ) {
        $vol = 0;
    }
    $itunes->{SoundVolume} = floor $vol;
}


sub convert_esc($$) {
    my $ch  = shift || die;
    my $msg = shift;


    if( $ch eq '\\' ) {
        "\\"
    } elsif( $ch eq 'a' ) {
        "\a"
    } elsif( $ch eq 'b' ) {
        "\b"
    } elsif( $ch eq 'cC' ) {
        "\cC"
    } elsif( $ch eq 'f' ) {
        "\f"
    } elsif( $ch eq 'n' ) {
        "\n"
    } elsif( $ch eq 'r' ) {
        "\r"
    } elsif( $ch eq 't' ) {
        "\t"
    } elsif( substr( $ch, 0, 1 ) eq 'l' ) {
        lc( $ch )
    } elsif( substr( $ch, 0, 1 ) eq 'u' ) {
        uc( $ch )
    } elsif( $ch eq 'L' && defined $msg ) {
        "\L$msg\E"
    } elsif( $ch eq 'Q' && defined $msg ) {
        "\Q$msg\E"
    } elsif( $ch eq 'U' && defined $msg ) {
        "\U$msg\E"
    } else {
        warn "warning: unexpected sequence.\n"   if( $debug );
        $ch;
    }
}


sub cmd_echo {
    my $quote = shift || die;
    my $msg   = shift || '';

    if( $quote eq '"' ) {
        # convert
        $msg =~ s/(?:\\(.|cC|l.|u.|L|Q|U)(?:(.*?)\\E)?)/ convert_esc( $1, $2 ) /eg;
    }

    print $msg;
}


sub cmd_show_info {
    my $opt = shift || '';


    my $track = $itunes->CurrentTrack;
    if( not $track ) {
        warn "not playing.\n";
        return;
    }

    # show basic information
    show_item_info(
        $track,
        qw( Name Artist Album )
    );
    say "Rate: " . "% " x ( $track->{Rating} / 20 );


    # verbose information
    if( $opt eq 'verbose' ) {
        show_item_info(
            $track,
            qw( Time SkippedCount Comment )
        );
        say sprintf "Size: %g MByte", $track->Size / 1048576;
        say sprintf "Playlist: %s [%d/%d]",
                $itunes->CurrentPlaylist->Name,
                $itunes->CurrentPlaylist->Tracks->Count,
                $itunes->LibraryPlaylist->Tracks->Count;
    }
}


sub cmd_list {
    my $all = shift eq 'all';
    my $tracks;

    if( $all ) {
        $tracks = $itunes->LibraryPlaylist->Tracks;
    } else {
        $tracks = $itunes->CurrentPlaylist->Tracks;
    }

    for ( 1..$tracks->Count ) {
        print "------------------------------------------\n";
        show_item_info(
            $tracks->Item( $_ ),
            qw( Name Artist )
        );
    }
}


sub cmd_search {
    my $opt = shift;

    if( not defined $opt ) {
        warn "No options.";
        return;
    }

    warn "not implemented yet.\n";

    #     eval "use Inline MzScheme => $opt";
}


sub cmd_with_toggle {
    my $toggle = shift || '';
    my $ref    = shift || die;

    if( $toggle eq '?' ) {
        toggle( $ref );
    } elsif( $toggle eq '!' ) {
        $$ref = 0;
    } else {
        $$ref = 1;
    }
}


sub toggle {
    my $val = shift || die;
    $$val = !$$val;
}


sub show_item_info {
    my $item = shift || die;
    my @lis  = @_    or die;

    p sprintf '@lis:[%s]', join ", ", @lis;

#     if( not defined $PIPE ) {
#         $PIPE = IO::Pipe->new();
#         $PIPE->writer( $pager );
#     }

    for ( @lis ) {
        if( $item->{$_} ) {
            print sprintf "$_: %s\n", $item->{$_};
        }
    }
#         eval "\$item->{\$_} && say $PIPE "$_: " . \$item->{\$_}";
#         warn "eval error:\n$@\n"     if( $@ );
}


sub cmd_for {
    my ( $times, $group ) = @_ or die;
    
    p "\$times:[$times]";
    p "\$group:[$group]";

    for ( 1..$times ) {
        command_parse( $group );
    }
}


sub command_read($) {
    my $stdin = shift || die;
    my $lines  = '';

    if( $shell_mode ) {
        # TODO
        while( 1 ) {
            $lines = <$stdin>;
            my ( $cmd, @args ) = command_parse( $lines, RETURN_EVENT );
            if( defined $cmd ) {
                command_exec(  );
            }
        }

    } else {
        $lines = <$stdin>;
    }

    $lines;
}


# if this finds characters looking commands,
#   run command_exec() with its characters.
# and this returns 0 when exit.
sub command_parse($;$) {
    my $cmd = shift || return TRUE;
    my $opt = shift || 0;


    p "calling command_parse()...";
    p "\$cmd:[$cmd]";

    # TODO: 末尾に'\\'があったらもう１行読む
    # command_read を追加？

    while( $cmd ) {

        # spaces, and characters to be ignored.
        $cmd =~ s/^$ignore_char+//;
        return TRUE     if( $cmd =~ /^#/ || !$cmd );

        # times
        my $times = 1;    # Don't move to outside of 'while'.
        if( $cmd =~ s/^(\d+)// ) {
            if( $1 > 0 ) {
                $times = $1;
            } else {
                warn "invalid times '$1'.\n";
                return $force_execute;    # continue reading if $force_execute.
            }
        }

        # exec N times.
        while( $times ) {

            # spaces, and characters to be ignored.
            # NOTE: loop never ends if /^$ignore_char*/.
            next            if( $cmd =~ s/^$ignore_char+// );
            return TRUE     if( $cmd =~ /^#/ || !$cmd );

            if( !command_exec( \$cmd, --$times ) ) {
                return $force_execute;
            }
        }
    }

    TRUE;
}


# if this happens on any errors, returns zero.
sub command_exec {
    my $cmd   = shift || return TRUE;
    my $times = shift;

    p "calling command_exec()...";


    foreach my $regex ( keys %commands ) {
        if( $$cmd =~ /$regex/ ) {

            p "matched regex '$regex'.";
            p "excuting...";

            # exec
            my @parens = check_matches();
            $commands{$regex}->( @parens[1..$#parens] );

            # executed N times.
            if( $times == 0 ) {
                $$cmd =~ s/$regex//;
                p "matched:[$&]";
            }

            p "excuted...";
            p sprintf 'rest $$cmd:[%s]', $$cmd;

            return TRUE;
        }
    }

    # Reaching here means no commands to match regex.

    my $ch = substr( $$cmd, 0, 1 );
    warn "unknown command '$ch'.\n";
    $$cmd = substr( $$cmd, 1 );

    # if return TRUE, continue parsing commands.
    $force_execute;
}


sub check_matches() {
    my @args;

    for( 1..10 ) {
        if( eval "defined \$$_" ) {
            push @args, eval "\$$_"
        } else {
            last;
        }
    }

    p sprintf "\@args:[%s]", join ", ", @args;
    @args;
}


# sleep but wake up if typed 'q' key.
sub sleep {
    my $sec  = shift;
    my $prev = time;

    while( time() - $prev < $sec ) {
        my $c = getch();

        if( $c && $c =~ /^q/ ) {
            print "Do you really want to quit?[y/n]: ";
            exit if( <STDIN> =~ /^[yY]/ );
        }
    }
}

### FUNCTIONS ###

### MAIN ###

STDOUT->autoflush( 1 );
STDERR->autoflush( 1 );

# arguments
my $help;
GetOptions(
    debug => \$debug,
    force => \$force_execute,
    shell => \$shell_mode,
    help  => \$help,
) or pod2usage( -verbose => 2 );
pod2usage( -verbose => 2 ) if( $help );

# read from file or stdin?
my $stdin;
if( @ARGV ) {
    my $file = shift @ARGV;
    $stdin = FileHandle->new( "< $file" );
    die "Not found '$file'\n" if( not defined $stdin );
} else {
    $stdin = \*STDIN;
}

# get COM object
$itunes = Win32::OLE->new( 'iTunes.Application' )
    or die "Could not find iTunes COM object...\n";



# Main loop
my $end   = 0;
my $input = '';

while( not $end ) {

    # prompt
    if( $shell_mode ) {
        print '$ ';
    } elsif( ref( $stdin ) eq 'GLOB' ) {
        print '> ';
    }

    $input = command_read( $stdin );

    if( not defined $input ) {
        # when EOF.
        exit;

    } elsif ( $input ) {
        chomp( $input );
        next if( $input =~ /^\s*$/ );

        command_parse( $input );
    }
}

say "\nbye.";
exit;
### MAIN ###

__END__

=head1 NAME

autotunes.pl - Manipulating iTunes from CLI


=head1 SYNOPSIS

$ perl autotunes.pl [-h] [file]


=head1 OPTIONS

    --help,-h    - This help text.
  

=head1 COMMANDS

    I, Info             Show more verbose information.
    Q, shutdown         Quit iTunes and this program.
    b, back             Back track.
    c, change           Play or Stop music.
                 (same thing you press the center button on iTunes)
    echo                Echo message from batch file.
    f, forward          Forward track.
    i, info             Show information about the music playing now.
    max                 Maximize window.
    mini                Toggle mini player.
    mute                Mute.
    p, play             Play music.
    q                   Quit this program.
    s, stop, pause      Stop music.
    srch, search        Search tracks. (Not implemented yet)
    tray                let iTunes window go to tray.
    vol [num]           Volume Control.


=head1 EXAMPLE

    > sl120 p    (Play music after 120 seconds)
    > p sl5 Q    (Stop music and quit program(without iTunes) after 300 seconds)
    > p sl1 c sl1 c sl1 c   (Play , Stop , Play, Stop each 1 second)


=head1 USABILITY

no use.

=cut

vim: noreadonly
