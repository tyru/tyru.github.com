#!/usr/bin/env perl
use strict;
use warnings;
use utf8;
use subs 'sleep';

use constant {
    EXPECT_CODE     => 1
};

use Encode;
use FileHandle;
use Perl6::Say;
use Data::Dumper;


our $debug;
our $itunes;
our $shell_mode;
our $force_execute;
our $Env;

our $ignored;
our $prev_read_line;


# our @commands;  # �S�ẴR�}���h��

# NOTE: �Œ���̂ЂȌ^ => qr/ \A (�R�}���h) /mx
our @commands = (
    {
        names => ['debug'],
        attr  => 'a+',
        proc  => \&cmd_debug,
        regex => 'qr/ \A ($cmd) (?: $ignored* (on|off|test
                                    |dump|code|eval|reload) )
                (?: $ignored* ([\w\W]*?) $ignored* ) ?  /mx'
    },
    {
        names => ['h', 'help'],
        attr  => '@a?',
        proc  => \&cmd_help,
        regex => 'qr/ \A ($cmd) (?: $ignored* (more) )? \b /mx'
    },
    {
        names => ['v','ver','version'],
        attr  => 'a0',
        proc  => \&cmd_version,
        regex => 'qr/ \A ($cmd) \b /mx'
    },
    {
        names => ['q','quit','bye'],
        attr  => 'a0',
        regex => 'qr/ \A ($cmd) \b /mx',
        proc  => sub { exit } },
    {
        names => ['Q','Quit'],
        attr  => 'a0',
        regex => 'qr/ \A ($cmd) \b /mx',
        proc  => sub { $itunes->Quit(); exit }
    },
    {
        names => ['vol','volume'],
        attr  => 'a1',
        regex => 'qr/ \A ($cmd) (?: $ignored* ([+-]? \d+)? ) \b /mx',
        proc  => \&cmd_volume
    },
    {
        names => ['echo'],
        attr  => 'a2',
        regex => 'qr/ \A ($cmd) (?: $ignored* (["\']) ([\w\W]*?) \2 )/mx',
        proc  => \&cmd_echo
    },
    {
        names => ['say'],
        attr  => 'a2',
        regex => 'qr/ \A ($cmd) (?: $ignored* (["\']) ([\w\W]*?) \2 )/mx',
        proc  =>  sub { cmd_echo( shift, shift()."\n" ) }
    },
    {
        names => ['sl','sleep'],
        attr  => 'a1',
        regex => 'qr/ \A ($cmd) (?: $ignored* (\d+) ) \b /mx',
        proc  => sub { sleep shift }
    },
    {
        names => ['p','play'],
        attr  => 'a0',
        regex => 'qr/ \A ($cmd) \b /mx',
        proc  => sub { $itunes->Play() }
    },
    {
        names => ['s','stop'],
        attr  => 'a0',
        regex => 'qr/ \A ($cmd) \b /mx',
        proc  => sub { $itunes->Pause() }
    },
    {
        names => ['c','change'],
        attr  => 'a0',
        regex => 'qr/ \A ($cmd) \b /mx',
        proc  => sub { $itunes->PlayPause() }
    },
    {
        names => ['f','forward'],
        attr  => 'a0',
        regex => 'qr/ \A ($cmd) \b /mx',
        proc  => sub { $itunes->NextTrack() }
    },
    {
        names => ['b','back'],
        attr  => 'a0',
        regex => 'qr/ \A ($cmd) \b /mx',
        proc  => sub { $itunes->BackTrack() }
    },
    {
        names => ['ff','fastforward'],
        attr  => 'a?',
        regex => 'qr/ \A ($cmd) (?: $ignored* (\d+) ) ? \b /mx',
        proc  => sub { $itunes->FastForward();
                       $_[0] && do { sleep shift;
                                     $itunes->Resume() } }
    },
    {
        names => ['bb','rewind'],
        attr  => 'a?',
        regex => 'qr/ \A ($cmd) (?: $ignored* (\d+) ) ? \b /mx',
        proc  => sub { $itunes->ReWind();
                       $_[0] && do { sleep shift;
                                     $itunes->Resume() } }
    },
    {
        names => ['re','resume'],
        attr  => 'a0',
        regex => 'qr/ \A ($cmd) \b /mx',
        proc  => sub { $itunes->Resume() }
    },
    {
        names => ['step'],
        attr  => 'a0',
        regex => 'qr/ \A ($cmd) \b /mx',
        proc  => sub { print 'press enter when resume...';
                       command_parse( 'ff fr re' ) }
    },
    {
        names => ['bstep','backstep'],
        attr  => 'a0',
        regex => 'qr/ \A ($cmd) \b /mx',
        proc  => sub { print 'press enter when resume...';
                       command_parse( 'bb fr re' ) }
    },
    {
        names => ['fr','freeze'],
        attr  => 'a*i',
        regex => 'qr/ \A ($cmd) (?: $ignored* (["\']) ([\w\W]*?) \2 ) ? /mx',
        proc  => sub { $_[1] && say $_[1]; <STDIN>; }
    },
    {
        names => ['pl'],
        attr  => 'a1',
        regex => 'qr/ \A ($cmd) (?: $ignored* ([+-]? \d+) ) \b /mx',
        proc  => sub { cmd_get_around_playlists( 'pl', @_ ) }
    },
    {
        names => ['fp'],
        attr  => 'a1',
        regex => 'qr/ \A ($cmd) (?: $ignored* ([+-]? \d+) )? \b /mx',
        proc  => sub { cmd_get_around_playlists( 'fp', @_ ) }
    },
    {
        names => ['bp'],
        attr  => 'a1',
        regex => 'qr/ \A ($cmd) (?: $ignored* ([+-]? \d+) )? \b /mx',
        proc  => sub { cmd_get_around_playlists( 'bp', @_ ) }
    },
    {
        names => ['apple'],
        attr  => 'a0',
        regex => 'qr/ \A ($cmd) \b /mx',
        proc  => sub { $itunes->GotoMusicStoreHomePage() }
    },
    {
        names => ['reveal'],
        attr  => 'a0',
        regex => 'qr/ \A ($cmd) \b /mx',
        proc  => sub { $itunes->CurrentTrack->Reveal() }
    },
    {
        names => ['pwd','i','info'],
        attr  => 'a?',
        regex => 'qr/ \A ($cmd) (?: $ignored* (verbose) )? \b /mx',
        proc  => \&cmd_info
    },
    {
        names => ['I','Info'],
        attr  => 'a0',
        regex => 'qr/ \A ($cmd) \b /mx',
        proc  => sub { cmd_info( 'verbose' ) }
    },
    {
        names => ['rate'],
        attr  => 'a1',
        regex => 'qr/ \A ($cmd) (?: $ignored* ([0-5]+) ) \b /mx',
        proc  => sub { $itunes->CurrentTrack->{Rating} = shift() * 20
                            if playing_now() }
    },
    {
        names => ['l','ls','list'],
        attr  => 'a?',
        regex => 'qr/ \A ($cmd) (?: $ignored* (all|playlist) )? \b /mx',
        proc  => \&cmd_list
    },
    {
        names => ['L','List'],
        attr  => 'a0',
        regex => 'qr/ \A ($cmd) \b /mx',
        proc  => sub { cmd_list( 'playlist' ) }
    },
    {
        names => ['find'],
        attr  => 'a1',
        regex => 'qr/ \A ($cmd) (?: $ignored* \(
                                        $ignored* ([\w\W]+?) $ignored*
                                \) ) /mx',
        proc  => \&cmd_find
    },
    {
        names => ['show'],
        attr  => 'a1',
        regex => 'qr/ \A ($cmd) (?: $ignored* (all|mute|max|mini|tray
                                    |shuffle|shell|force) ) \b /mx',
        proc  => \&cmd_show
    },
    {
        names => ['mute'],
        attr  => 'a?',
        regex => 'qr/ \A ($cmd) ( [\?!] )? /mx',
        proc  => sub { cmd_with_toggle( shift, \$itunes->{Mute} ) }
    },
    {
        names => ['max'],
        attr  => 'a?',
        regex => 'qr/ \A ($cmd) ( [\?!] )? /mx',
        proc  => sub { cmd_with_toggle( shift,
                            \$itunes->BrowserWindow->{Maximized} ) }
    },
    {
        names => ['mini'],
        attr  => 'a?',
        regex => 'qr/ \A ($cmd) ( [\?!] )? /mx',
        proc  => sub { cmd_with_toggle( shift,
                            \$itunes->BrowserWindow->{MiniPlayer} ) }
    },
    {
        names => ['tray'],
        attr  => 'a?',
        regex => 'qr/ \A ($cmd) ( [\?!] )? /mx',
        proc  => sub { cmd_with_toggle( shift,
                            \$itunes->BrowserWindow->{Minimized} ) }
    },
    {
        names => ['shuffle'],
        attr  => 'a?',
        regex => 'qr/ \A ($cmd) ( [\?!] )? /mx',
        proc  => sub { cmd_with_toggle( shift,
                            \$itunes->CurrentPlaylist->{Shuffle} )
                                if playing_now() }
    },

    # shell, load, for, etc...
    {
        names => ['shell'],
        attr  => 'a?',
        regex => 'qr/ \A ($cmd) ( [\?!] )? /mx',
        proc  => sub { cmd_with_toggle( shift, \$shell_mode ) }
    },
    {
        names => ['force'],
        attr  => 'a?',
        regex => 'qr/ \A ($cmd) ( [\?!] )? /mx',
        proc  => sub { cmd_with_toggle( shift, \$force_execute ) }
    },
    {
        names => ['pager'],
        attr  => undef,
        regex => 'qr/ \A ($cmd) $ignored* (?: (more|less|on|off|eval) | $ignored*
                                                    $ignored* ([\w\W]*?)
                                                $ignored* ) ) \b /mx',
        proc   => \&cmd_pager
    },
    {
        names => ['load'],
        attr  => 'a1',
        regex => 'qr/ \A ($cmd) (?: $ignored* (["\']) ([\w\W]*?) \2 ) /mx',
        proc  => \&cmd_load
    },
    {
        names => ['for'],
        attr  => 'a2',
        regex => 'qr/ \A ($cmd) $ignored* ([1-9][0-9]*)
                    (?: $ignored* ([\w\W]*) $ignored*) /xm',
        proc  => \&cmd_for,
    },
    {
        names => ['def'],
        attr  => 'a2',
        regex => 'qr/ \A ($cmd) (?: $ignored* (\w+) $ignored* ([\w\W]*)) /mx',
        proc  => \&cmd_def
    },
    {
        names => ['undef'],
        attr  => 'a1',
        regex => 'qr/ \A ($cmd) (?: $ignored* (\w+)) \b /mx',
        proc  => \&cmd_undef
    },
    {
        names => ['!!'],
        attr  => 'a0',
        regex => 'qr/ \A ($cmd) /mx',
        proc  => sub { command_parse( $prev_read_line )
                            if $prev_read_line !~ /!!/m }
    },
#     {
#         names => ['it'],
#     },


#     qr/\Awhile$ignored*\((.*?)\)/ => \&cmd_while,
#     qr/\Aif$ignored*\((.*?)\)$ignored*{(.*?)}/m => \&cmd_if,
);


### FUNCTIONS ###


sub cmd_debug {
    my $what = shift || die;
    my @args = @_    or ();


    if( $what eq 'on' ) {
        $debug = 1;

    } elsif( $what eq 'off' ) {
        $debug = 0;

    } elsif( $what eq 'test' ) {
        if( -f 'test.it' ) {
            cmd_load( '"', 'test.it' );
        } else {
            warn_if_debug "warning: not found 'test.it'...\n";
        }

    } elsif( $what eq 'eval' ) {
        eval join ' ', @args;

    } elsif( $what eq 'dump' ) {
        local $Data::Dumper::Sortkeys = 1;
        local $Data::Dumper::Indent   = 1;
        local $Data::Dumper::Terse    = 1;
        p Dumper( $itunes ), 'dump.log';

    } elsif( $what eq 'reload' ) {
        # FIXME: require�͊��Ƀ��[�h�������͎̂��s���Ȃ�
        require 'commands.pl';

    } elsif( $what eq 'code' ) {
        # code here...
    }
}


sub cmd_volume {
    my $vol = shift;

    if( not defined $vol ) {
        # mute
        toggle( \$itunes->{mute} );
        return;
    }

    if( $vol =~ /\A([+-])(\d+)/ ) {
        $vol = eval $itunes->{SoundVolume} . " $1 $2";
    }

    # round to 0..100
    if( $vol >= 100 ) {
        $vol = 100;
    } elsif ( $vol < 0 ) {
        $vol = 0;
    }

    require POSIX;
    $itunes->{SoundVolume} = POSIX::floor( $vol );
}


sub convert_esc($$) {
    my $ch  = shift || die;
    my $msg = shift;


    if( $ch eq '\\' ) { # "\\\\" to "\\"
        "\\"
    } elsif( $ch eq 'a' ) {
        "\a"
    } elsif( $ch eq 'b' ) {
        "\b"
    } elsif( substr( $ch, 0, 1 ) eq 'c' ) {
        eval "\\$ch"    # FIXME: don't work
    } elsif( $ch eq 'f' ) {
        "\f"
    } elsif( $ch eq 'n' ) {
        "\n"
    } elsif( $ch eq 'r' ) {
        "\r"
    } elsif( $ch eq 't' ) {
        "\t"
    } elsif( substr( $ch, 0, 1 ) eq 'l' ) {
        lc( $ch )
    } elsif( substr( $ch, 0, 1 ) eq 'u' ) {
        uc( $ch )
    } elsif( $ch eq 'L' && defined $msg ) {
        "\L$msg\E"
    } elsif( $ch eq 'Q' && defined $msg ) {
        "\Q$msg\E"
    } elsif( $ch eq 'U' && defined $msg ) {
        "\U$msg\E"
    } else {
        warn_if_debug "warning: unexpected sequence.\n";
        $ch;
    }
}


sub cmd_echo {
    my $quote = shift || die;
    my $msg   = shift || '';

    # convert
    if( $quote eq '"' ) {
        no warnings;
        $msg =~ s/(?:\\(.|c.|l.|u.|L|Q|U)(?:(.*?)\\E)?)/ convert_esc( $1, $2 ) /eg;
        use warnings;
    }

    print $msg;
}


# XXX
sub cmd_get_around_playlists {
    return      if not playing_now();

    my $cmd = shift || die;
    my $n   = shift || 1;


    my $lib_lst = $itunes->LibraryPlaylist->Source->Playlists;
    my $max_id  = $lib_lst->Count;
    my $cur_id  = $itunes->CurrentPlaylist->Index - 5;


    ### debug - begin
    p "current/max playlist id is [$cur_id/$max_id]";
    ### debug - end


    if( $cmd eq 'pl' ) {
        my $item = $lib_lst->Item( $n );
        $item->PlayFirstTrack();

    } elsif( $cmd eq 'fp' ) {
        my $id = $cur_id + $n;

        if( $id <= 0 ) {
            $id = 1;
        } elsif( $id >= $max_id ) {
            $id = $max_id;
        }
        my $item    = $lib_lst->Item( $id );
        $item->{Visible} = 1;

    } elsif( $cmd eq 'bp' ) {
        my $id = $cur_id - $n;

        ### debug - begin
        p "\$id:[$id]";
        ### debug - end

        if( $id <= 0 ) {
            $id = 1;
        } elsif( $id >= $max_id ) {
            $id = $max_id;
        }
        my $item    = $lib_lst->Item( $id );
        $item->{Visible} = 1;
#         $lib_lst->Item( $id )->PlayFirstTrack();
    }
}


sub cmd_info {
    my $opt = shift || '';


    my $track = $itunes->CurrentTrack;
    if( not playing_now() ) {
        warn "not playing.\n";
        return;
    }

    # show basic information
    show_item_info(
        $track,
        qw( Name Artist Album )
    );
    say "Rate: " . "% " x ( $track->{Rating} / 20 );


    # verbose information
    if( $opt eq 'verbose' ) {
        show_item_info(
            $track,
            qw( Time SkippedCount Comment )
        );
        say sprintf "Size: %g MByte", $track->Size / 1048576;
        say sprintf "Playlist: %s [%d/%d]",
                $itunes->CurrentPlaylist->Name,
                $itunes->CurrentPlaylist->Tracks->Count,
                $itunes->LibraryPlaylist->Tracks->Count;
    }
}


sub cmd_list {
    my $opt = shift;
    my $tracks;

    if( $opt eq 'all' ) {
        $tracks = $itunes->LibraryPlaylist->Tracks;
    } elsif( $opt eq 'playlist' ) {
        $tracks = $itunes->LibraryPlaylist->Source->Playlists;
    } else {
        $tracks = $itunes->CurrentPlaylist->Tracks;
    }

    for ( 1..$tracks->Count ) {
        print "----- Item $_ -----\n";
        show_item_info(
            $tracks->Item( $_ ),
            qw( Name Artist playlistID )
        );
    }
}


{
    my %options = (
        song => 'Name',
        singer => 'Artist',
        artist => 'Artist',
    );

    sub cmd_find {
        return      if not playing_now();

        my $input  = shift || die;
        my $tracks = $itunes->CurrentPlaylist->Tracks;
        my $prev   = '';
        my %cond;
        my ( $keys_n, $found_n ) = ( 0, 0 );


        # just push ':key (value)?' sequence into %cond.
        while( $input ) {
            # cut $ignored
            $input =~ s/\A$ignored*//;

            # next if not key string parsed
            if( substr( $input, 0, 1 ) ne ':' ) {
                warn_if_debug "warning: expected key.";
                next;
            }
            # infinite loop...
            if( $prev eq $input ) {
                warn_if_debug "warning: useless loop detected...\n"
                            . "end cmd_find()";
                return;
            }
            $prev = $input;

            # get key and value, delete
            $input =~ s/:(\w+)(?:$ignored+(\w+))?//;

            $cond{$1} = $2;
            $keys_n++;


            p sprintf "key: %s, value: %s", $1, $2 || '';
        }


        for ( 1..$tracks->Count ) {
            my $item =  $tracks->Item( $_ );

            for my $sect ( keys %cond ) {

                # if defined 'key'(e.g. 'song', 'singer'...),
                # and $options has that key.
                if( exists $options{$sect} ) {

                    # and $item's member of
                    # that $options value is matched specified 'value'.
                    #   e.g. $item->Name =~ /���Ԕ�s/
                    if( defined $options{$sect}
                        && $item->{ $options{$sect} } =~ /$cond{$sect}/ )
                    {
                        $found_n++;
                        next    unless( exists $cond{all} && $keys_n == $found_n );


                        # show, play, and more (*describing about this routine*)
                        if( !( exists $cond{q} || exists $cond{quiet} ) ) {
                            say $item->Name;
                        }
                        if( exists $cond{play} ) {
                            $item->Play();
                        }
                    }

                } else {
                    warn_if_debug "warning:  cmd_find(): unknown option given.";
                }
            }
        }
    }
}


{
    my %name_and_bool = (
        mute    => \$itunes->Mute,
        max     => \$itunes->BrowserWindow->Maximized,
        mini    => \$itunes->BrowserWindow->MiniPlayer,
        shuffle => sub { $itunes->CurrentPlaylist->Shuffle
                            if playing_now() },
        shell   => \$shell_mode,
        force   => \$force_execute
    );

    sub cmd_show {
        my $name = shift || die;
        my $bool;


        if( $name eq 'all' ) {
            foreach ( sort keys %name_and_bool ) {

                if( ref $name_and_bool{$_} eq 'SCALAR' ) {
                    if( ${$name_and_bool{$_}} ) {
                        say "$_ is on.";
                    } else {
                        say "$_ is off.";
                    }

                } elsif( ref $name_and_bool{$_} eq 'CODE' ) {
                    if( ${name_and_bool{$_}}->() ) {
                        say "$_ is on.";
                    } else {
                        say "$_ is off.";
                    }
                }
            }

        } elsif( exists $name_and_bool{$name} ) {
            if( ${$name_and_bool{$name}} ) {
                say 'on.';
            } else {
                say 'off.';
            }

        } else {
            warn_if_debug "not found option '$name'.\n";
        }
    }
}


# XXX
sub cmd_pager {
    my @opts  = @_;
    my $state = 0;

    ### debug - begin
    p "calling cmd_pager()...";
    p sprintf '@opts:[%s]', join ", ", @opts;
    ### debug - end


    require IO::Pipe;

    foreach my $opt ( @opts ) {

        if( $opt eq 'on' ) {
            if( not $Env->{PIPED} ) {
                my $FH  = IO::Pipe->new;
                $FH->writer( $Env->{PAGER} );
                die $!    if not defined $FH;

                system( 'cls' );
                $Env->{STDOUT} = $FH;
                $Env->{PIPED}  = 1;
            }

        } elsif( $opt eq 'off' ) {
            if( $Env->{PIPED} ) {
                $Env->{STDOUT} = \*STDOUT;
                $Env->{PIPED} = 0;
            }
# 
#         } elsif( $opt eq 'more' ) {
#             $pager = $Env->{PAGER}{MORE};
# 
#         } elsif( $opt eq 'less' ) {
#             $pager = $Env->{PAGER}

        } elsif( $opt eq 'eval' ) {
            $state = EXPECT_CODE;     # code after this

        } elsif( $state == EXPECT_CODE ) {
#             command_parse( $opt );
            my ( $times, $proc, @args ) = command_parse( $opt, RETURN_IF_FOUND );

            if( defined $proc ) {
                # exec.
                for ( 1..$times ) {
                    $proc->( @args );
                }
            }

            $state = 0;  # reset
        }
    }
}


sub cmd_load {
    my $fname = $_[1] || die;
    my $FH = FileHandle->new( "< $fname" );
    if( not defined $FH ) {
        warn "error: Can't open $fname...\n";
        return;
    }

    while( 1 ) {
        my $input = command_read( $FH );

        if( not defined $input ) {  # EOF
            return;

        } elsif( $input ) {
            chomp( $input );
            next    if $input =~ /\A\s*$/;

            command_parse( $input );
        }
    }
}


sub cmd_for {
    my ( $times, $group ) = @_;
    return      if not $group;

    ### debug - begin
    p "\$times:[$times]";
    p "\$group:[$group]";
    ### debug - end

    for ( 1..$times ) {
        command_parse( $group );
    }
}


{
    my @macros = ();

    # FIXME: attr �� i ���܂ރR�}���h����������macro��attr�ɂ�i��t����
    sub cmd_def {
        my $name  = shift || die;
        my $macro = shift || '';


        if( grep { $name eq $_ } @macros ) {
            warn "'$name' is already defined.\n";
        } else {
            push @commands, {
                names => [$name],
                attr  => 'a0u',
                proc  => sub { command_parse( $macro ) },
                regex => 'qr/ \A ($cmd) \b /mx'
            };
            push @macros, $name;
        }
    }

    sub cmd_undef {
        my $name = shift || die;

        p "\$name:[$name]";
        p "\@macros:[@macros]";


        if( ! grep { $name eq $_ } @macros ) {
            warn "macro '$name' is not found.\n";
            STDERR->flush;
            return;
        }

        @commands = grep {
            my $command = $_;
            if( grep { $_ eq $name } @{$$command{names}} ) {
                0;  # �폜
            } else {
                $command;
            }
        } @commands;
        @macros = grep { $_ ne $name } @macros;
    }
}


sub show_item_info {
    my $item = shift || die;
    my @lis  = @_    or die;

    ### debug - begin
    p sprintf '@lis:[%s]', join ", ", @lis;
    ### debug - end


    for ( @lis ) {
        if( $item->{$_} ) {
            print sprintf "%s: %s\n", $_, $item->{$_};
        }
    }
#         eval "\$item->{\$_} && say $PIPE "$_: " . \$item->{\$_}";
#         warn "eval error:\n$@\n"     if( $@ );
}


sub cmd_with_toggle {
    my $toggle = shift || '';
    my $ref    = shift || die;

    if( $toggle eq '?' ) {
        toggle( $ref );
    } elsif( $toggle eq '!' ) {
        $$ref = 0;
    } else {
        $$ref = 1;
    }
}


sub playing_now() {
    return defined $itunes->CurrentPlaylist;
}


sub toggle {
    my $val = shift || die;
    $$val = !$$val;
}


# sleep but wake up and ask you when typed 'q' key.
sub sleep {
    my $sec  = shift;
    my $prev = time;

    require Term::Getch;

    while( time() - $prev < $sec ) {
        my $c = Term::Getch->getch();

        if( $c && $c =~ /^q/ ) {
            print "Do you really want to quit?[y/n]: ";
            exit    if <STDIN> =~ /^[yY]/;
        }
    }
}


1;
