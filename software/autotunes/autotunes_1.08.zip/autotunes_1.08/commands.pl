#!/usr/bin/env perl
use strict;
use warnings;
use utf8;
use subs 'sleep';

use constant {
    EXPECT_CODE     => 1
};

use Encode;
use FileHandle;
use IO::Pipe;
use List::MoreUtils qw( any );
use POSIX qw( floor );
use Perl6::Say;
use Term::Getch;
use Win32;    # for Sleep


our $debug;
our $itunes;
our $shell_mode;
our $force_execute;
our $OPT;


our @commands;  # �S�ẴR�}���h��

# NOTE: �Œ���̂ЂȌ^ => qr/ ^ (�R�}���h) /mx
our %commands = (
    'debug@a+'      => {
        proc   =>  \&cmd_debug,
        regex  => 'qr/ ^ ($cmd) (?: $ignored* (on|off|cmd|test
                                    |dump|code|eval|reload) )
                                         (?: $ignored* (?:do)?
                                            $ignored* ([\w\W]*?)
                                         $ignored* $end ) ?  /mx', },
    'h|help@a?'         => { regex => 'qr/ ^ ($cmd) (?: $ignored* (verbose) )? \b /mx',
                             proc  => \&cmd_help },
    'v|ver|version@a0'  => { regex => 'qr/ ^ ($cmd) \b /mx',
                             proc  => \&cmd_version },
    'q|quit|bye@a0'     => { regex => 'qr/ ^ ($cmd) \b /mx',
                             proc  => sub { exit } },
    'Q|Quit@a0'         => { regex => 'qr/ ^ ($cmd) \b /mx',
                             proc  => sub { $itunes->Quit(); exit } },
    'vol|volume@a1'     => { regex => 'qr/ ^ ($cmd) (?: $ignored* ([+-]? \d+)? ) \b /mx',
                             proc  => \&cmd_volume },

    'echo@a2'           => { regex => 'qr/ ^ ($cmd)
                                           (?: $ignored* (["\']) ([\w\W]*?) \2 )/mx',
                             proc  => \&cmd_echo },
    'say@a2'            => { regex => 'qr/ ^ ($cmd)
                                             (?: $ignored* (["\']) ([\w\W]*?) \2 )/mx',
                             proc  =>  sub { cmd_echo( shift, shift()."\n" )}},
    'sl|sleep@a1'       => { regex => 'qr/ ^ ($cmd) (?: $ignored* (\d+) ) \b /mx',
                             proc  => sub { sleep shift }},
    'p|play@a0'         => { regex => 'qr/ ^ ($cmd) \b /mx',
                             proc  => sub { $itunes->Play() }},
    's|stop@a0'         => { regex => 'qr/ ^ ($cmd) \b /mx',
                             proc  => sub { $itunes->Pause() }},
    'c|change@a0'       => { regex => 'qr/ ^ ($cmd) \b /mx',
                             proc  => sub { $itunes->PlayPause() }},
    'f|forward@a0'      => { regex => 'qr/ ^ ($cmd) \b /mx',
                             proc  => sub { $itunes->NextTrack() }},
    'b|back@a0'         => { regex => 'qr/ ^ ($cmd) \b /mx',
                             proc  => sub { $itunes->BackTrack() }},
    'ff|fastforward@a?' => { regex => 'qr/ ^ ($cmd) (?: $ignored* (\d+) ) ? \b /mx',
                             proc  => sub { $itunes->FastForward();
                                              $_[0] && do {
                                                  sleep shift;
                                                  $itunes->Resume() }}},
    'bb|rewind@a?'      => { regex => 'qr/ ^ ($cmd) (?: $ignored* (\d+) ) ? \b /mx',
                             proc  => sub { $itunes->ReWind();
                                              $_[0] && do {
                                                  sleep shift;
                                                  $itunes->Resume() }}},
    're|resume@a0'      => { regex => 'qr/ ^ ($cmd) \b /mx',
                             proc  => sub { $itunes->Resume() }},
    'step@a0'           => { regex => 'qr/ ^ ($cmd) \b /mx',
                             proc  => sub { print 'press enter when resume...' ;
                                             command_parse( 'ff fr re' ) }},
    'fr|freeze@a*i'     => { regex => 'qr/ ^ ($cmd)
                                    (?: $ignored* (["\']) ([\w\W]*?) \2 ) ? /mx',
                             proc  => sub { $_[1] && say $_[1];
                                            <STDIN>; } },
    'pl@a1'     => { regex => 'qr/ ^ ($cmd) (?: $ignored* ([+-]? \d+) ) \b /mx',
                     proc  => sub { cmd_get_around_playlists( 'pl', @_ ) } },
    'fp@a1'     => { regex => 'qr/ ^ ($cmd) (?: $ignored* ([+-]? \d+) )? \b /mx',
                     proc  => sub { cmd_get_around_playlists( 'fp', @_ ) } },
    'bp@a1'     => { regex => 'qr/ ^ ($cmd) (?: $ignored* ([+-]? \d+) )? \b /mx',
                     proc  => sub { cmd_get_around_playlists( 'bp', @_ ) } },
    'apple@a0'  => { regex => 'qr/ ^ ($cmd) \b /mx',
                     proc  => sub { $itunes->GotoMusicStoreHomePage() } },

    'reveal@a0' => { regex => 'qr/ ^ ($cmd) \b /mx',
                     proc  => sub { $itunes->CurrentTrack->Reveal() } },
    'pwd|i|info@a?' => { regex => 'qr/ ^ ($cmd) (?: $ignored* (verbose) )? \b /mx',
                         proc  => \&cmd_info },
    'I|Info@a0' => { regex => 'qr/ ^ ($cmd) \b /mx',
                     proc  => sub { cmd_info( 'verbose' ) } },
    'rate@a1'   => { regex => 'qr/ ^ ($cmd) (?: $ignored* ([0-5]+) ) \b /mx',
                     proc  => sub { $itunes->CurrentTrack->{Rating}
                                            = shift() * 20 } },
    'l|ls|list@a?' => { regex => 'qr/ ^ ($cmd) (?: $ignored* (all|playlist) )? \b /mx',
                        proc  => \&cmd_list },
    'L|List@a0'    => { regex => 'qr/ ^ ($cmd) \b /mx',
                        proc  => sub { cmd_list( 'playlist' ) } },

    'srch|search@a1' => { regex => 'qr/ ^ ($cmd) (?: $ignored* ([\w\W]*) ) /mx',
                          proc  => \&cmd_search },

    'show@a1' => { regex => 'qr/ ^ ($cmd) (?: $ignored* (all|mute|max|mini|tray
                                                |shuffle|shell|force) ) \b /mx',
                   proc  => \&cmd_show },

    'mute@a?' => { regex => 'qr/ ^ ($cmd) ( [\\?!] )? /mx',
                   proc  => sub { cmd_with_toggle(
                                        shift,
                                        \$itunes->{Mute} ) }},
    'max@a?'  => { regex => 'qr/ ^ ($cmd) ( [\\?!] )? /mx',
                   proc  => sub { cmd_with_toggle(
                                        shift,
                                        \$itunes->BrowserWindow->{Maximized} ) }},
    'mini@a?' => { regex => 'qr/ ^ ($cmd) ( [\\?!] )? /mx',
                   proc  => sub { cmd_with_toggle(
                                        shift,
                                        \$itunes->BrowserWindow->{MiniPlayer} ) }},

    'tray@a?' => { regex => 'qr/ ^ ($cmd) ( [\\?!] )? /mx',
                   proc  => sub { cmd_with_toggle(
                                        shift,
                                        \$itunes->BrowserWindow->{Minimized} ) }},
    'shuffle@a?' => { regex => 'qr/ ^ ($cmd) ( [\\?!] )? /mx',
                      proc  => sub { cmd_with_toggle(
                                        shift,
                                        \$itunes->CurrentPlaylist->{Shuffle} ) }},

    # shell, load, for, etc...
    'shell@a?' => { regex => 'qr/ ^ ($cmd) ( [\\?!] )? /mx',
                    proc  => sub { cmd_with_toggle( shift, \$shell_mode ) }},
    'force@a?' => { regex => 'qr/ ^ ($cmd) ( [\\?!] )? /mx',
                    proc  => sub { cmd_with_toggle( shift, \$force_execute ) }},
    'pager' => { regex => 'qr/ ^ ($cmd) $ignored* (?: (more|less|on|off|eval)
                                              | $ignored*
                                                    $ignored* ([\w\W]*?)
                                                $ignored* ) ) \b /mx',
                 proc   => \&cmd_pager },
    'load@a1'  => { regex => 'qr/ ^ ($cmd)
                                (?: $ignored* (["\']) ([\w\W]*?) \2 ) /mx',
                    proc  => \&cmd_load },
    'for@a2'   => { regex => 'qr/ ^ ($cmd) $ignored* ([1-9][0-9]*)
                                    (?: $ignored* ([\w\W]*) $ignored*) /xm',
                    proc  => \&cmd_for },
    'def@a2'   => { regex => 'qr/ ^ ($cmd)
                            (?: $ignored* (\w+) $ignored* ([\w\W]*)) /mx',
                    proc  => \&cmd_def },
    'undef@a1' => { regex => 'qr/ ^ ($cmd) (?: $ignored* (\w+)) \b /mx',
                    proc  => \&cmd_undef },

#     qr/^while$ignored*\((.*?)\)/ => \&cmd_while,
#     qr/^if$ignored*\((.*?)\)$ignored*{(.*?)}/m => \&cmd_if,
);


### FUNCTIONS ###

sub cmd_volume {
    my $vol = shift;

    if( not defined $vol ) {
        # mute
        toggle( \$itunes->{mute} );
        return;
    }

    if( $vol =~ /^([+-])(\d+)/ ) {
        $vol = eval $itunes->{soundvolume} . " $1 $2";
    }

    # round to 0..100
    if( $vol >= 100 ) {
        $vol = 100;
    } elsif ( $vol < 0 ) {
        $vol = 0;
    }
    $itunes->{SoundVolume} = floor $vol;
}


sub convert_esc($$) {
    my $ch  = shift || die;
    my $msg = shift;


    if( $ch eq '\\' ) {     # not change
        "\\"
    } elsif( $ch eq 'a' ) {
        "\a"
    } elsif( $ch eq 'b' ) {
        "\b"
    } elsif( $ch eq 'cC' ) {
        "\cC"
    } elsif( $ch eq 'f' ) {
        "\f"
    } elsif( $ch eq 'n' ) {
        "\n"
    } elsif( $ch eq 'r' ) {
        "\r"
    } elsif( $ch eq 't' ) {
        "\t"
    } elsif( substr( $ch, 0, 1 ) eq 'l' ) {
        lc( $ch )
    } elsif( substr( $ch, 0, 1 ) eq 'u' ) {
        uc( $ch )
    } elsif( $ch eq 'L' && defined $msg ) {
        "\L$msg\E"
    } elsif( $ch eq 'Q' && defined $msg ) {
        "\Q$msg\E"
    } elsif( $ch eq 'U' && defined $msg ) {
        "\U$msg\E"
    } else {
        warn_if_debug "warning: unexpected sequence.\n";
        $ch;
    }
}


sub cmd_echo {
    my $quote = shift || die;
    my $msg   = shift || '';

    # convert
    if( $quote eq '"' ) {
        $msg =~ s/(?:\\(.|cC|l.|u.|L|Q|U)(?:(.*?)\\E)?)/ convert_esc( $1, $2 ) /eg;
    }

    print $msg;
}


# XXX
sub cmd_get_around_playlists {
    return      if( not playing_now() );

    my $cmd = shift || die;
    my $n   = shift || 1;


    my $lib_lst = $itunes->LibraryPlaylist->Source->Playlists;
    my $max_id  = $lib_lst->Count;
    my $cur_id  = $itunes->CurrentPlaylist->Index - 5;


    ### debug - begin
    p "current/max playlist id is [$cur_id/$max_id]";
    ### debug - end


    if( $cmd eq 'pl' ) {
        my $item = $lib_lst->Item( $n );
        $item->PlayFirstTrack();

    } elsif( $cmd eq 'fp' ) {
        my $id = $cur_id + $n;

        if( $id <= 0 ) {
            $id = 1;
        } elsif( $id >= $max_id ) {
            $id = $max_id;
        }
        my $item    = $lib_lst->Item( $id );
        $item->{Visible} = 1;

    } elsif( $cmd eq 'bp' ) {
        my $id = $cur_id - $n;

        ### debug - begin
        p "\$id:[$id]";
        ### debug - end

        if( $id <= 0 ) {
            $id = 1;
        } elsif( $id >= $max_id ) {
            $id = $max_id;
        }
        my $item    = $lib_lst->Item( $id );
        $item->{Visible} = 1;
#         $lib_lst->Item( $id )->PlayFirstTrack();
    }
}


sub cmd_info {
    my $opt = shift || '';


    my $track = $itunes->CurrentTrack;
    if( not $track ) {
        warn "not playing.\n";
        return;
    }

    # show basic information
    show_item_info(
        $track,
        qw( Name Artist Album )
    );
    say "Rate: " . "% " x ( $track->{Rating} / 20 );


    # verbose information
    if( $opt eq 'verbose' ) {
        show_item_info(
            $track,
            qw( Time SkippedCount Comment )
        );
        say sprintf "Size: %g MByte", $track->Size / 1048576;
        say sprintf "Playlist: %s [%d/%d]",
                $itunes->CurrentPlaylist->Name,
                $itunes->CurrentPlaylist->Tracks->Count,
                $itunes->LibraryPlaylist->Tracks->Count;
    }
}


sub cmd_list {
    my $opt = shift;
    my $tracks;

    if( $opt eq 'all' ) {
        $tracks = $itunes->LibraryPlaylist->Tracks;
    } elsif( $opt eq 'playlist' ) {
        $tracks = $itunes->LibraryPlaylist->Source->Playlists;
    } else {
        $tracks = $itunes->CurrentPlaylist->Tracks;
    }

    for ( 1..$tracks->Count ) {
        print "----- Item $_ -----\n";
        show_item_info(
            $tracks->Item( $_ ),
            qw( Name Artist playlistID )
        );
    }
}


sub cmd_search {
    my $opt = shift;

    if( not defined $opt ) {
        warn "No options.";
        return;
    }

    warn "not implemented yet.\n";

    #     eval "use Inline MzScheme => $opt";
}


{
    my %name_and_bool = (
        mute    => \$itunes->Mute,
        max     => \$itunes->BrowserWindow->Maximized,
        mini    => \$itunes->BrowserWindow->MiniPlayer,
        shuffle => sub { $itunes->CurrentPlaylist->Shuffle
                            if( playing_now() ) },
        shell   => \$shell_mode,
        force   => \$force_execute
    );

    sub cmd_show {
        my $name = shift || die;
        my $bool;


        if( $name eq 'all' ) {
            foreach ( sort keys %name_and_bool ) {

                if( ref $name_and_bool{$_} eq 'SCALAR' ) {
                    if( ${$name_and_bool{$_}} ) {
                        say "$_ is on.";
                    } else {
                        say "$_ is off.";
                    }

                } elsif( ref $name_and_bool{$_} eq 'CODE' ) {
                    if( ${name_and_bool{$_}}->() ) {
                        say "$_ is on.";
                    } else {
                        say "$_ is off.";
                    }
                }
            }

        } elsif( exists $name_and_bool{$name} ) {
            if( ${$name_and_bool{$name}} ) {
                say "on.";
            } else {
                say "off.";
            }

        } else {
            warn_if_debug "not found option '$name'.\n";
        }
    }
}


# XXX
sub cmd_pager {
    my @opts  = @_;
    my $state = 0;

    ### debug - begin
    p "calling cmd_pager()...";
    p sprintf '@opts:[%s]', join ", ", @opts;
    ### debug - end


    foreach my $opt ( @opts ) {

        if( $opt eq 'on' ) {
            if( not $OPT->{PIPED} ) {
                my $FH  = IO::Pipe->new;
                $FH->writer( $OPT->{PAGER} );
                die $!    if( not defined $FH );

                system( 'cls' );
                $OPT->{STDOUT} = $FH;
                $OPT->{PIPED}  = 1;
            }

        } elsif( $opt eq 'off' ) {
            if( $OPT->{PIPED} ) {
                $OPT->{STDOUT} = \*STDOUT;
                $OPT->{PIPED} = 0;
            }
# 
#         } elsif( $opt eq 'more' ) {
#             $pager = $OPT->{PAGER}{MORE};
# 
#         } elsif( $opt eq 'less' ) {
#             $pager = $OPT->{PAGER}

        } elsif( $opt eq 'eval' ) {
            $state = EXPECT_CODE;     # code after this

        } elsif( $state == EXPECT_CODE ) {
#             command_parse( $opt );
            my ( $times, $proc, @args ) = command_parse( $opt, RETURN_IF_FOUND );

            if( defined $proc ) {
                # exec.
                for ( 1..$times ) {
                    $proc->( @args );
                }
            }

            $state = 0;  # reset
        }
    }
}


sub cmd_load {
    my $fname = $_[1] || die;
    my $FH = FileHandle->new( "< $fname" );
    if( not defined $FH ) {
        warn "error: Can't open $fname...\n";
        return;
    }

    while( 1 ) {
        my $input = command_read( $FH );

        if( not defined $input ) {  # EOF
            return;

        } elsif( $input ) {
            chomp( $input );
            next if( $input =~ /^\s*$/ );

            command_parse( $input );
        }
    }
}


sub cmd_for {
    my ( $times, $group ) = @_ or die;
    return      if( not defined $group );

    ### debug - begin
    p "\$times:[$times]";
    p "\$group:[$group]";
    ### debug - end

    for ( 1..$times ) {
        command_parse( $group );
    }
}


sub cmd_def {
    my $name  = shift || die;
    my $macro = shift || '';

    if( any { $name eq $_ } @commands ) {
        warn "'$name' is already defined.\n";
    } else {
        my $key = $name . '@u';     # user's def
        $commands{$key} = {
            regex => 'qr/ ^ ($cmd) \b /mx',
            proc  => sub { command_parse( $macro ) }
        };
        push @commands, $name;
    }
}


sub cmd_undef {
    my $name = shift || die;
    my $key  = $name . '@u';    # user's def

    if( not defined ( delete $commands{$key} ) ) {
        warn "macro '$name' is not found.\n";
    }
    @commands = grep { $_ ne $name } @commands;
}

sub show_item_info {
    my $item = shift || die;
    my @lis  = @_    or die;

    ### debug - begin
    p sprintf '@lis:[%s]', join ", ", @lis;
    ### debug - end


    for ( @lis ) {
        if( $item->{$_} ) {
            print sprintf "%s: %s\n", $_, $item->{$_};
        }
    }
#         eval "\$item->{\$_} && say $PIPE "$_: " . \$item->{\$_}";
#         warn "eval error:\n$@\n"     if( $@ );
}


sub cmd_with_toggle {
    my $toggle = shift || '';
    my $ref    = shift || die;

    if( $toggle eq '?' ) {
        toggle( $ref );
    } elsif( $toggle eq '!' ) {
        $$ref = 0;
    } else {
        $$ref = 1;
    }
}


sub playing_now() {
    return defined $itunes->CurrentPlaylist;
}


sub toggle {
    my $val = shift || die;
    $$val = !$$val;
}


# sleep but wake up and ask you when typed 'q' key.
sub sleep {
    my $sec  = shift;
    my $prev = time;

    while( time() - $prev < $sec ) {
        my $c = getch();

        if( $c && $c =~ /^q/ ) {
            print "Do you really want to quit?[y/n]: ";
            exit if( <STDIN> =~ /^[yY]/ );
        }
    }
}


1;
