#!/usr/bin/env perl

use strict;
use warnings;
use subs 'sleep';

use constant {
    TRUE         => 1,
    FALSE        => 0,
    RETURN_IF_FOUND => -1
};

use Encode;
use File::Basename qw( basename );
use File::Spec::Functions qw( :ALL );
use FileHandle;
use Getopt::Long;
use IO::Pipe;
use POSIX qw( floor );
use Perl6::Say;
use Pod::Usage;
use Term::Getch;
use Win32::OLE;
use Win32;    # for Sleep


# TODO:
#   command_parse関数がコマンドを見つけたらそれを返す(あれば引数つき)
#   command_parse関数はcommand_execに渡すとき先頭の引数は渡さない

our $debug         = 0;
our $VERSION       = 1.04;

our $force_execute = 0;
our $shell_mode    = 0;
our $pager         = 'less';
our $PIPE;

our $itunes;    # COM object
our $ignore_char = '[\s\n:;]';


# NOTE: 最低限のひな型 => qr/ ^ (コマンド) /mx
our %commands = (
    'debug'         => { 'regex' => 'qr/ ^ ($_) (?:\s*(cmd|test))? \b /mx',
                         'sub'   =>  \&cmd_debug },
    'h|help'        => { 'regex' => 'qr/ ^ ($_) \b /mx',
                         'sub'   => \&cmd_help, },
    'v|ver|version' => { 'regex' => 'qr/ ^ ($_) \b /mx',
                         'sub'   => \&cmd_version, },
    'q|quit|bye'    => { 'regex' => 'qr/ ^ ($_) \b /mx',
                         'sub'   => sub { exit } },
    'Q|Quit'        => { 'regex' => 'qr/ ^ ($_) \b /mx',
                         'sub'   => sub { $itunes->Quit(); exit } },
    'vol|volume'    => { 'regex' => 'qr/ ^ ($_) (?: \s* ([+-]? \d+)? ) \b /mx',
                         'sub'   => \&cmd_volume },

#     qr/ ^ (debug) (?:\s*(cmds))? \b /mx
#         => \&cmd_debug,
#     qr/ ^ (h|help) \b /mx
#         => \&cmd_help,
#     qr/ ^ (v|ver|version) \b /mx
#         => \&cmd_version,
#     qr/ ^ (q|quit|bye) \b /mx
#         => sub { exit },
#     qr/ ^ (Q|Quit) \b /mx
#         => sub { $itunes->Quit(); exit },
# 
#     qr/ ^ (vol) (?: \s* ([+-]?\d+)? ) \b /mx
#         => \&cmd_volume,


    'echo'      => { 'regex' => 'qr/ ^ ($_) (?: \s* (["\']) (.*?) \2 )/mx',
                     'sub'   => \&cmd_echo },
    'say'       => { 'regex' => 'qr/ ^ ($_) (?: \s* (["\']) (.*?) \2 )/mx',
                     'sub'   =>  sub { cmd_echo( $_[0], $_[1] . "\n" ) } },
    'sl|sleep'  => { 'regex' => 'qr/ ^ ($_) (?: \s* (\d+) ) \b /mx',
                     'sub'   => sub { sleep shift } },
    'p|play'    => { 'regex' => 'qr/ ^ ($_) \b /mx',
                     'sub'   => sub { $itunes->Play() } },
    's|stop'    => { 'regex' => 'qr/ ^ ($_) \b /mx',
                     'sub'   => sub { $itunes->Pause() } },
    'c|change'  => { 'regex' => 'qr/ ^ ($_) \b /mx',
                     'sub'   => sub { $itunes->PlayPause() } },
    'f|forward' => { 'regex' => 'qr/ ^ ($_) \b /mx',
                     'sub'   => sub { $itunes->NextTrack() } },
    'b|back'    => { 'regex' => 'qr/ ^ ($_) \b /mx',
                     'sub'   => sub { $itunes->BackTrack() } },

#     qr/ ^ (echo) (?: \s* (["']) (.*?) \2 ) /mx
#         => \&cmd_echo,
#     qr/ ^ (say) (?: \s* (["']) (.*?) \2 ) /mx
#         => sub { cmd_echo( $_[0], $_[1] . "\n" ) },
#     qr/ ^ (sl|sleep) (?: \s* (\d+) ) \b /mx
#         => sub { sleep $_[0] },
#     qr/ ^ (p|play) \b /mx
#         => sub { $itunes->Play() },
#     qr/ ^ (s|stop) \b /mx
#         => sub { $itunes->Pause() },
#     qr/ ^ (c|change) \b /mx
#         => sub { $itunes->PlayPause() },
#     qr/ ^ (f|forward) \b /mx
#         => sub { $itunes->NextTrack() },
#     qr/ ^ (b|back) \b /mx
#         => sub { $itunes->BackTrack() },


    'i|info' => { 'regex' => 'qr/ ^ ($_) (?: \s* (verbose) )? \b /mx',
                  'sub'   => \&cmd_show_info },
    'I|Info' => { 'regex' => 'qr/ ^ ($_) \b /mx',
                  'sub'   => sub { cmd_show_info( 'verbose' ) } },
    'rate'   => { 'regex' => 'qr/ ^ ($_) (?: \s* ([0-5]+) ) \b /mx',
                  'sub'   => sub { $itunes->CurrentTrack->{Rating} = shift() * 20 } },
    'l|list' => { 'regex' => 'qr/ ^ ($_) (?: \s* (all) )? \b /mx',
                  'sub'   => \&cmd_list },
    'L|List' => { 'regex' => 'qr/ ^ ($_) \b /mx',
                  'sub'   => sub { cmd_list( 'all' ) } },
    'srch|search' => { 'regex' => 'qr/ ^ ($_) (?: \s* \( (.*?) \) ) /mx',
                       'sub'   => \&cmd_search },

#     qr/ ^ (i|info) (?: \s* (verbose) )? \b /mx
#         => \&cmd_show_info,
#     qr/ ^ (I|Info) \b /mx
#         => sub { cmd_show_info( 'verbose' ) },
#     qr/ ^ (rate) (?: \s* ([0-5]+) ) \b /mx
#         => sub { $itunes->CurrentTrack->{Rating} = shift() * 20 },
#     qr/ ^ (l|list) (?: \s* (all) )? \b /mx
#         => \&cmd_list,
#     qr/ ^ (L|List) \b /mx
#         => sub { cmd_list( 'all' ) },
#     qr/ ^ (srch|search) (?: \s* \( (.*?) \) ) /mx
#         => \&cmd_search,


    'mute' => { 'regex' => 'qr/ ^ ($_) ( [\\?!] )? /mx',
                'sub'   => sub { cmd_with_toggle(
                                    shift,
                                    \$itunes->{Mute} ) } },
    'max'  => { 'regex' => 'qr/ ^ ($_) ( [\\?!] )? /mx',
                'sub'   => sub { cmd_with_toggle(
                                    shift,
                                    \$itunes->BrowserWindow->{Maximized} ) } },
    'mini' => { 'regex' => 'qr/ ^ ($_) ( [\\?!] )? /mx',
                'sub'   => sub { cmd_with_toggle(
                                    shift,
                                    \$itunes->BrowserWindow->{MiniPlayer} ) } },

    'tray' => { 'regex' => 'qr/ ^ ($_) ( [\\?!] )? /mx',
                'sub'   => sub { cmd_with_toggle(
                                    shift,
                                    \$itunes->BrowserWindow->{Minimized} ) } },

#     qr/ ^ (mute) ( [\?!] )? /mx
#         => sub { cmd_with_toggle(
#                         shift,
#                         \$itunes->{Mute} ) },
#     qr/ ^ (max) ( [\?!] )? /mx
#         => sub { cmd_with_toggle(
#                         shift,
#                         \$itunes->BrowserWindow->{Maximized} ) },
#     qr/ ^ (mini) ( [\?!] )? /mx
#         => sub { cmd_with_toggle(
#                         shift,
#                         \$itunes->BrowserWindow->{MiniPlayer} ) },
#     qr/ ^ (tray) ( [\?!] )? /mx
#         => sub { cmd_with_toggle(
#                         shift,
#                         \$itunes->BrowserWindow->{Minimized} ) },


    # shell, load, for, etc...
    'shell' => { 'regex' => 'qr/ ^ ($_) ( [\\?!] )? /mx',
                 'sub'   => sub { cmd_with_toggle( shift, \$shell_mode ) } },
    'force' => { 'regex' => 'qr/ ^ ($_) ( [\\?!] )? /mx',
                 'sub'   => sub { cmd_with_toggle( shift, \$force_execute ) } },
    'load'  => { 'regex' => 'qr/ ^ ($_) (?: \s* (\S+) ) \b /mx',
                 'sub'   => \&cmd_load },
    'for'   => { 'regex' => 'qr/ ^ ($_) \s* ([1-9][0-9]*) (?:\s* times)?
                                $ignore_char* do
                                    \s* ([\w\W]*?)
                                $ignore_char* done /xm',
                 'sub'   => \&cmd_for },

#     qr/ ^ (shell) ( [\?!] )? /mx
#         => sub { cmd_with_toggle( shift, \$shell_mode ) },
# 
#     qr/ ^ (force) ( [\?!] )? /mx
#         => sub { cmd_with_toggle( shift, \$force_execute ) },
# 
#     qr/ ^ (load) (?: \s* (\S+) ) \b /mx
#         => \&cmd_load,

#     qr/^while\s*\((.*?)\)/ => \&cmd_while,
#     qr/^if\s*\((.*?)\)\s*{(.*?)}/m => \&cmd_if,

#     qr/ ^ (for) \s* ([1-9][0-9]*) (?:\s* times)?
#         $ignore_char* do
#             \s* ([\w\W]*?)
#         $ignore_char* done /xm              => \&cmd_for,
);

### FUNCTIONS ###

### debug - begin
### for debug print.
sub p {
    return unless $debug;
    my $str   = shift || '';
    my $fname = shift;
    my $msg   = encode(
        'sjis',
        "[debug]### $str ###\n"
    );

    if( defined $fname ) {
        my $FH = FileHandle->new( ">> $fname" );
        print $FH $msg;
        $FH->close;
    } else {
        warn $msg;
    }
}
### debug - end


sub cmd_debug {
    my $what = shift || die;

    if( $what eq 'cmd' ) {
        for my $key ( keys %commands ) {
            my @cmds = split /\|/, $key;
            say join ", ", @cmds;
        }
    } elsif( $what eq 'test' ) {
        if( -f 'test.it' ) {
            cmd_load( 'test.it' );
        } else {
            warn "not found 'test.it'...\n";
        }
    }
}


sub cmd_help {
    pod2usage(
        -verbose => 2,
        -exitval => 'NOEXIT'
    );
}


sub cmd_version {
    say "iTunes v", $itunes->Version;
    say basename( $0 ) . " v$VERSION";
}


sub cmd_volume {
    my $vol = shift;

    if( not defined $vol ) {
        # mute
        toggle( \$itunes->{Mute} );
        return;
    }

    if( $vol =~ /^([+-])(\d+)/ ) {
        $vol = eval $itunes->{SoundVolume} . " $1 $2";
    }

    # round to 0..100
    if( $vol >= 100 ) {
        $vol = 100;
    } elsif ( $vol < 0 ) {
        $vol = 0;
    }
    $itunes->{SoundVolume} = floor $vol;
}


sub convert_esc($$) {
    my $ch  = shift || die;
    my $msg = shift;


    if( $ch eq '\\' ) {
        "\\"
    } elsif( $ch eq 'a' ) {
        "\a"
    } elsif( $ch eq 'b' ) {
        "\b"
    } elsif( $ch eq 'cC' ) {
        "\cC"
    } elsif( $ch eq 'f' ) {
        "\f"
    } elsif( $ch eq 'n' ) {
        "\n"
    } elsif( $ch eq 'r' ) {
        "\r"
    } elsif( $ch eq 't' ) {
        "\t"
    } elsif( substr( $ch, 0, 1 ) eq 'l' ) {
        lc( $ch )
    } elsif( substr( $ch, 0, 1 ) eq 'u' ) {
        uc( $ch )
    } elsif( $ch eq 'L' && defined $msg ) {
        "\L$msg\E"
    } elsif( $ch eq 'Q' && defined $msg ) {
        "\Q$msg\E"
    } elsif( $ch eq 'U' && defined $msg ) {
        "\U$msg\E"
    } else {
        warn "warning: unexpected sequence.\n"   if( $debug );
        $ch;
    }
}


sub cmd_echo {
    my $quote = shift || die;
    my $msg   = shift || '';

    # convert
    if( $quote eq '"' ) {
        $msg =~ s/(?:\\(.|cC|l.|u.|L|Q|U)(?:(.*?)\\E)?)/ convert_esc( $1, $2 ) /eg;
    }

    print $msg;
}


sub cmd_show_info {
    my $opt = shift || '';


    my $track = $itunes->CurrentTrack;
    if( not $track ) {
        warn "not playing.\n";
        return;
    }

    # show basic information
    show_item_info(
        $track,
        qw( Name Artist Album )
    );
    say "Rate: " . "% " x ( $track->{Rating} / 20 );


    # verbose information
    if( $opt eq 'verbose' ) {
        show_item_info(
            $track,
            qw( Time SkippedCount Comment )
        );
        say sprintf "Size: %g MByte", $track->Size / 1048576;
        say sprintf "Playlist: %s [%d/%d]",
                $itunes->CurrentPlaylist->Name,
                $itunes->CurrentPlaylist->Tracks->Count,
                $itunes->LibraryPlaylist->Tracks->Count;
    }
}


sub cmd_list {
    my $all = shift eq 'all';
    my $tracks;

    if( $all ) {
        $tracks = $itunes->LibraryPlaylist->Tracks;
    } else {
        $tracks = $itunes->CurrentPlaylist->Tracks;
    }

    for ( 1..$tracks->Count ) {
        print "------------------------------------------\n";
        show_item_info(
            $tracks->Item( $_ ),
            qw( Name Artist )
        );
    }
}


sub cmd_search {
    my $opt = shift;

    if( not defined $opt ) {
        warn "No options.";
        return;
    }

    warn "not implemented yet.\n";

    #     eval "use Inline MzScheme => $opt";
}


sub cmd_load {
    my $fname = shift || die;
    my $FH = FileHandle->new( "< $fname" );
    if( not defined $FH ) {
        warn "error: Can't open $fname...\n";
        return;
    }

    while( 1 ) {
        my $input = command_read( $FH );

        if( not defined $input ) {  # EOF
            return;

        } elsif( $input ) {
            chomp( $input );
            next if( $input =~ /^\s*$/ );

            command_parse( $input );
        }
    }
}


sub cmd_with_toggle {
    my $toggle = shift || '';
    my $ref    = shift || die;

    if( $toggle eq '?' ) {
        toggle( $ref );
    } elsif( $toggle eq '!' ) {
        $$ref = 0;
    } else {
        $$ref = 1;
    }
}


sub toggle {
    my $val = shift || die;
    $$val = !$$val;
}


sub show_item_info {
    my $item = shift || die;
    my @lis  = @_    or die;

    ### debug - begin
    p sprintf '@lis:[%s]', join ", ", @lis;
    ### debug - end


#     if( not defined $PIPE ) {
#         $PIPE = IO::Pipe->new();
#         $PIPE->writer( $pager );
#     }

    for ( @lis ) {
        if( $item->{$_} ) {
            print sprintf "$_: %s\n", $item->{$_};
        }
    }
#         eval "\$item->{\$_} && say $PIPE "$_: " . \$item->{\$_}";
#         warn "eval error:\n$@\n"     if( $@ );
}


sub cmd_for {
    my ( $times, $group ) = @_ or die;
    
    ### debug - begin
    p "\$times:[$times]";
    p "\$group:[$group]";
    ### debug - end

    for ( 1..$times ) {
        command_parse( $group );
    }
}


sub command_read_user($) {
    my $stdin = shift || die;
    my $lines = '';


    while( 1 ) {
        my $input = <$stdin>;

        if( not defined $input ) {  # EOF
            if( $lines ) {
                return $lines;  # read a few lines yet.
            } else {
                return undef;   # No read lines. just undef.
            }
        }

        chomp( $input );

        ### debug - begin
        p "read [$input].";
        ### debug - end

        if( $lines ) {
            $lines .= "\n";
        }

        # 末尾に'\\'か';'があったらもう１行読む
        if( substr( $input, -1 ) =~ /[\\;]/ ) {
            $lines .= substr( $input, 0, -1 );
            next;

        } else {
            $lines .= $input;
            return $lines;      # end
        }
    }
}


sub command_read_shell($) {
    my $stdin = shift || die;
    my $lines = '';

    while( 1 ) {
        $lines = <$stdin>;
        my ( $sub, @parens ) = command_parse( $lines, RETURN_IF_FOUND );

        if( defined $sub ) {

            ### debug - begin
            p "execute...";
            ### debug - end

            $sub->( @parens[1..$#parens] );

            ### debug - begin
            p "executed...";
            ### debug - end
        }
    }
}


sub command_read($) {
    my $stdin  = shift || die;
    my $lines  = '';

    ### debug - begin
    p "calling command_read()...";
    p sprintf "Read from %s", ref $stdin;
    ### debug - end


    if( $shell_mode ) {
        # シェルモード

        ### debug - begin
        p "Shell Input.";
        ### debug - end

        # おもしろいことができそう(現在はshell機能なし)
        command_read_shell( $stdin );

    } else {
        # ユーザ入力

        ### debug - begin
        p "User Input.";
        ### debug - end

        command_read_user( $stdin );
    }
}


# if this finds characters looking commands,
#   run command_exec() with its characters.
# and this returns 0 when exit.
sub command_parse($;$) {
    my $cmd = shift || return TRUE;
    my $opt = shift || 0;


    ### debug - begin
    p "calling command_parse()...";
    p "\$cmd:[$cmd]";
    ### debug - end


    # parse until $cmd becomes empty.
    while( $cmd ) {

        # spaces, and characters to be ignored.
        $cmd =~ s/^$ignore_char+//;
        return TRUE     if( $cmd =~ /^#/ || !$cmd );

        # get N times to run command.
        my $times = 1;    # Don't move to outside of 'while'.
        if( $cmd =~ s/^(\d+)// ) {
            if( $1 > 0 ) {
                $times = $1;
            } else {
                warn "invalid times '$1'.\n";
                return $force_execute;    # continue reading if $force_execute.
            }
        }

        # exec N times.
EXEC:   while( $times > 0 ) {

            # execute if matched regex.
            foreach my $cmd_name ( keys %commands ) {
                my $regex = $commands{$cmd_name}->{regex};
                my $sub   = $commands{$cmd_name}->{sub};

                # my $regex = $_->{regex};
                # my $sub   = $_->{sub};

                # make regex from template.
                $_ = $cmd_name;
                $regex = eval $regex;

                # spaces, and characters to be ignored.
                # NOTE: loop never ends if /^$ignore_char*/.
                next   EXEC     if( $cmd =~ s/^$ignore_char+// );
                return TRUE     if( $cmd =~ /^#/ || !$cmd );


                if( $cmd =~ /$regex/ ) {
                    my @parens = check_matches();

                    if( $opt == RETURN_IF_FOUND ) {
                        return $sub, @parens;
                    }


                    ### debug - begin
                    p "matched regex '$regex' at '$&'.";
                    p "excuting...";
                    p sprintf '@parens:[%s]', join ", ", @parens;
                    ### debug - end

                    # exec
                    $sub->( @parens[1..$#parens] );

                    # executed N times.
                    if( $times == 1 ) {
                        $cmd =~ s/$regex//;
                    }

                    ### debug - begin
                    p "excuted...";
                    p "rest of \$cmd:[$cmd]";
                    ### debug - end

                    last EXEC;
                }
            }

            # XXX
            warn sprintf "unknown command '%s'.\n",
                            substr( $cmd, 0, 1 );
            warn "Debug Trace:\n  [$cmd]";
            print "\n";

            $cmd = substr( $cmd, 1 );

            # return on parse error.
            if( not $force_execute ) {
                return undef;
            }

            $times--;
        }
    }

    return TRUE;
}


# 現在の$1, $2を調べてマッチしたぶんを配列で返す
sub check_matches() {
    my @args;

    for( 1..10 ) {
        if( eval "defined \$$_" ) {
            push @args, eval "\$$_"
        } else {
            last;
        }
    }

    ### debug - begin
    p sprintf "\@args:[%s]", join ", ", @args;
    ### debug - end

    @args;
}


# sleep but wake up and ask you when typed 'q' key.
sub sleep {
    my $sec  = shift;
    my $prev = time;

    while( time() - $prev < $sec ) {
        my $c = getch();

        if( $c && $c =~ /^q/ ) {
            print "Do you really want to quit?[y/n]: ";
            exit if( <STDIN> =~ /^[yY]/ );
        }
    }
}

### FUNCTIONS ###

### MAIN ###

STDOUT->autoflush( 1 );
STDERR->autoflush( 1 );

# arguments
my $help;
GetOptions(
    debug => \$debug,
    force => \$force_execute,
    shell => \$shell_mode,
    help  => \$help,
) or pod2usage( -verbose => 2 );
pod2usage( -verbose => 2 ) if( $help );

# read from file or stdin?
my $stdin;
if( @ARGV ) {
    my $file = shift @ARGV;
    $stdin = FileHandle->new( "< $file" );
    die "Not found '$file'\n" if( not defined $stdin );
} else {
    $stdin = \*STDIN;
}

# get COM object
$itunes = Win32::OLE->new( 'iTunes.Application' )
    or die "Could not find iTunes COM object...\n";



# Main loop
my $end   = 0;
my $input = '';

while( not $end ) {

    # prompt
    if( $shell_mode ) {
        print '$ ';
    } elsif( ref( $stdin ) eq 'GLOB' ) {
        print '> ';
    }

    $input = command_read( $stdin );

    if( not defined $input ) {
        # when EOF.
        exit;

    } elsif ( $input ) {
        chomp( $input );
        next if( $input =~ /^\s*$/ );

        command_parse( $input );
    }
}

say "\nbye.";
exit;
### MAIN ###

__END__

=head1 NAME

autotunes.pl - Manipulating iTunes from CLI


=head1 SYNOPSIS

$ perl autotunes.pl [-h] [file]


=head1 OPTIONS

    h, help             This help text.
    f, force            force parsing when error occurs.
    s, shell            entering shell mode.(This turns by 'shell' command, too.)
  

=head1 COMMANDS

    I, Info             Show more verbose information.
    Q, shutdown         Quit iTunes and this program.
    b, back             Back track.
    c, change           Play or Stop music.
                 (same thing you press the center button on iTunes)
    echo                Echo message from batch file.
    f, forward          Forward track.
    i, info             Show information about the music playing now.
    max                 Maximize window.
    mini                Toggle mini player.
    mute                Mute.
    p, play             Play music.
    q                   Quit this program.
    s, stop, pause      Stop music.
    srch, search        Search tracks. (Not implemented yet)
    tray                let iTunes window go to tray.
    vol [num]           Volume Control.


=head1 EXAMPLE

    > sl120 p    (Play music after 120 seconds)
    > p sl5 Q    (Stop music and quit program(without iTunes) after 300 seconds)
    > p sl1 c sl1 c sl1 c   (Play , Stop , Play, Stop each 1 second)


=head1 USABILITY

no use.

